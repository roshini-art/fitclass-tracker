<?php
// Database connection
$servername = "localhost"; // Change if needed
$username = "root"; // Change based on your DB user
$password = ""; // Change based on your DB password
$dbname = "fitness_booking"; 

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get current date
$report_date = date('Y-m-d');

// --- Calculate Bookings Data ---
$total_bookings = $conn->query("SELECT COUNT(*) AS count FROM bookings")->fetch_assoc()['count'];
$successful_bookings = $conn->query("SELECT COUNT(*) AS count FROM bookings WHERE payment_status='Completed'")->fetch_assoc()['count'];
$canceled_bookings = $total_bookings - $successful_bookings;

// --- Get Most Booked Package ---
$most_booked_package = $conn->query("SELECT package_type FROM bookings GROUP BY package_type ORDER BY COUNT(*) DESC LIMIT 1")->fetch_assoc()['package_type'] ?? 'None';

// --- Monthly Booking Trends ---
$bookings_this_month = $conn->query("SELECT COUNT(*) AS count FROM bookings WHERE MONTH(start_date) = MONTH(CURDATE())")->fetch_assoc()['count'];
$bookings_last_month = $conn->query("SELECT COUNT(*) AS count FROM bookings WHERE MONTH(start_date) = MONTH(CURDATE()) - 1")->fetch_assoc()['count'];

// --- Payment Insights ---
$total_payments = $conn->query("SELECT SUM(price) AS sum FROM bookings")->fetch_assoc()['sum'] ?? 0;
$pending_payments = $conn->query("SELECT SUM(price) AS sum FROM bookings WHERE payment_status='Pending'")->fetch_assoc()['sum'] ?? 0;
$completed_payments = $conn->query("SELECT SUM(price) AS sum FROM bookings WHERE payment_status='Completed'")->fetch_assoc()['sum'] ?? 0;
$refunded_payments = $conn->query("SELECT SUM(price) AS sum FROM bookings WHERE payment_status='Refunded'")->fetch_assoc()['sum'] ?? 0;

// --- Monthly Payment Trends ---
$payments_this_month = $conn->query("SELECT SUM(price) AS sum FROM bookings WHERE MONTH(start_date) = MONTH(CURDATE())")->fetch_assoc()['sum'] ?? 0;
$payments_last_month = $conn->query("SELECT SUM(price) AS sum FROM bookings WHERE MONTH(start_date) = MONTH(CURDATE()) - 1")->fetch_assoc()['sum'] ?? 0;

// --- Class Insights ---
$total_classes = $conn->query("SELECT COUNT(*) AS count FROM classes")->fetch_assoc()['count'];
$highest_booked_class = $conn->query("SELECT class_name FROM classes JOIN bookings ON classes.id = bookings.class_id GROUP BY class_name ORDER BY COUNT(*) DESC LIMIT 1")->fetch_assoc()['class_name'] ?? 'None';
$least_booked_class = $conn->query("SELECT class_name FROM classes JOIN bookings ON classes.id = bookings.class_id GROUP BY class_name ORDER BY COUNT(*) ASC LIMIT 1")->fetch_assoc()['class_name'] ?? 'None';

// --- Attendance Insights ---
$total_attendance = $conn->query("SELECT COUNT(*) AS count FROM attendees WHERE status='Present'")->fetch_assoc()['count'];
$total_absentees = $conn->query("SELECT COUNT(*) AS count FROM attendees WHERE status='Absent'")->fetch_assoc()['count'];
$attendance_rate = $total_bookings > 0 ? ($total_attendance / $total_bookings) * 100 : 0;

// --- Trainer Insights ---
$total_trainers = $conn->query("SELECT COUNT(*) AS count FROM trainers")->fetch_assoc()['count'];
$top_performing_trainer = $conn->query("SELECT name FROM trainers JOIN bookings ON trainers.id = bookings.trainer_id GROUP BY name ORDER BY COUNT(*) DESC LIMIT 1")->fetch_assoc()['name'] ?? 'None';
$least_active_trainer = $conn->query("SELECT name FROM trainers JOIN bookings ON trainers.id = bookings.trainer_id GROUP BY name ORDER BY COUNT(*) ASC LIMIT 1")->fetch_assoc()['name'] ?? 'None';

// --- User Insights ---
$total_users = $conn->query("SELECT COUNT(*) AS count FROM users")->fetch_assoc()['count'];
$new_users = $conn->query("SELECT COUNT(*) AS count FROM users WHERE MONTH(dob) = MONTH(CURDATE())")->fetch_assoc()['count'];
$most_active_user = $conn->query("SELECT username FROM users JOIN bookings ON users.id = bookings.user_id GROUP BY username ORDER BY COUNT(*) DESC LIMIT 1")->fetch_assoc()['username'] ?? 'None';

// --- Revenue Insights ---
$total_revenue = $completed_payments;
$highest_revenue_source = $most_booked_package;
$lowest_revenue_source = $conn->query("SELECT package_type FROM bookings GROUP BY package_type ORDER BY COUNT(*) ASC LIMIT 1")->fetch_assoc()['package_type'] ?? 'None';

// Insert into admin_reports
$sql = "INSERT INTO admin_reports (
    report_type, report_date, total_bookings, successful_bookings, canceled_bookings, 
    most_booked_package, bookings_this_month, bookings_last_month, 
    total_payments, pending_payments, completed_payments, refunded_payments, 
    payments_this_month, payments_last_month, total_classes, highest_booked_class, 
    least_booked_class, total_attendance, total_absentees, attendance_rate, 
    total_users, new_users, most_active_user, total_trainers, 
    top_performing_trainer, least_active_trainer, total_revenue, 
    highest_revenue_source, lowest_revenue_source, generated_by, report_status, remarks
) VALUES (
    'Bookings', '$report_date', $total_bookings, $successful_bookings, $canceled_bookings, 
    '$most_booked_package', $bookings_this_month, $bookings_last_month, 
    $total_payments, $pending_payments, $completed_payments, $refunded_payments, 
    $payments_this_month, $payments_last_month, $total_classes, '$highest_booked_class', 
    '$least_booked_class', $total_attendance, $total_absentees, $attendance_rate, 
    $total_users, $new_users, '$most_active_user', $total_trainers, 
    '$top_performing_trainer', '$least_active_trainer', $total_revenue, 
    '$highest_revenue_source', '$lowest_revenue_source', 1, 'Finalized', 'Automated report generation'
)";

if ($conn->query($sql) === TRUE) {
    echo "Admin report generated successfully!";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
