<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Fitness Tracker</title>
    <style>
        :root {
            --primary: #007bff; /* Blue for accents */
            --primary-dark: #0056b3; /* Darker blue for hover */
            --bg: #f4f4f9; /* Light gray background */
            --white: #fff; /* White for sections */
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            --text: #333; /* Dark text color */
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
            padding: 2rem;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        header {
            text-align: center;
            padding: 2rem 0;
            background: var(--white);
            border-radius: 8px;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }

        header h1 {
            color: var(--primary);
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }

        header p {
            font-size: 1.2rem;
            color: #666;
        }

        .about-section {
            background: var(--white);
            padding: 2rem;
            border-radius: 8px;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }

        .about-section h2 {
            color: var(--primary);
            font-size: 1.75rem;
            margin-bottom: 1rem;
        }

        .about-section p {
            font-size: 1rem;
            margin-bottom: 1rem;
        }

        .team {
            display: flex;
            flex-wrap: wrap;
            gap: 2rem;
            justify-content: center;
        }

        .team-member {
            background: #f9f9f9;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 300px;
            text-align: center;
        }

        .team-member h3 {
            color: var(--primary);
            font-size: 1.25rem;
            margin-bottom: 0.5rem;
        }

        .team-member p {
            color: #666;
            font-size: 0.9rem;
        }

        footer {
            text-align: center;
            padding: 1rem 0;
            font-size: 0.9rem;
            color: #666;
        }

        a {
            color: var(--primary);
            text-decoration: none;
        }

        a:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            header h1 {
                font-size: 2rem;
            }
            header p {
                font-size: 1rem;
            }
            .about-section h2 {
                font-size: 1.5rem;
            }
            .team-member {
                max-width: 100%;
            }
        }

        @media (max-width: 480px) {
            body {
                padding: 1rem;
            }
            header {
                padding: 1.5rem 0;
            }
            .about-section {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>About Us</h1>
            <p>Your Fitness Journey Starts Here</p>
        </header>

        <section class="about-section">
            <h2>Our Mission</h2>
            <p>
                At Fitness Tracker, we’re dedicated to helping you achieve your fitness goals through innovative tools and expert guidance. Whether you're a beginner or a seasoned athlete, our platform connects you with top trainers and provides insights to keep you motivated and on track.
            </p>
            <p>
                Founded in 2023, our mission is to make fitness accessible, enjoyable, and effective for everyone. We believe in empowering individuals with the knowledge and support they need to lead healthier lives.
            </p>
        </section>

        <section class="about-section">
            <h2>Meet Our Team</h2>
            <div class="team">
                <div class="team-member">
                    <h3>Jane Doe</h3>
                    <p>Founder & CEO</p>
                    <p>With over 10 years in fitness tech, Jane drives our vision to revolutionize how people approach wellness.</p>
                </div>
                <div class="team-member">
                    <h3>John Smith</h3>
                    <p>Head Trainer</p>
                    <p>A certified fitness expert, John designs programs that inspire and deliver results.</p>
                </div>
                <div class="team-member">
                    <h3>Emily Johnson</h3>
                    <p>Tech Lead</p>
                    <p>Emily ensures our platform is fast, reliable, and user-friendly.</p>
                </div>
            </div>
        </section>

        <footer>
            <p>&copy; <?php echo date('Y'); ?> Fitness Tracker. All rights reserved. | <a href="contact.php">Contact Us</a></p>
        </footer>
    </div>
</body>
</html>