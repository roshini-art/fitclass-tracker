<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services - Fitness Tracker</title>
    <style>
        :root {
            --primary: #007bff; /* Blue for accents */
            --primary-dark: #0056b3; /* Darker blue for hover */
            --bg: #f4f4f9; /* Light gray background */
            --white: #fff; /* White for sections */
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            --text: #333; /* Dark text color */
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
            padding: 2rem;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        header {
            text-align: center;
            padding: 2rem 0;
            background: var(--white);
            border-radius: 8px;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }

        header h1 {
            color: var(--primary);
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }

        header p {
            font-size: 1.2rem;
            color: #666;
        }

        .services-section {
            background: var(--white);
            padding: 2rem;
            border-radius: 8px;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }

        .services-section h2 {
            color: var(--primary);
            font-size: 1.75rem;
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .services-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 2rem;
            justify-content: center;
        }

        .service-card {
            background: #f9f9f9;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 350px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        .service-card h3 {
            color: var(--primary);
            font-size: 1.25rem;
            margin-bottom: 0.75rem;
        }

        .service-card p {
            color: #666;
            font-size: 0.95rem;
            margin-bottom: 1rem;
        }

        .service-card .btn {
            display: inline-block;
            padding: 0.5rem 1rem;
            background: var(--primary);
            color: var(--white);
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9rem;
            transition: background 0.3s ease;
        }

        .service-card .btn:hover {
            background: var(--primary-dark);
        }

        footer {
            text-align: center;
            padding: 1rem 0;
            font-size: 0.9rem;
            color: #666;
        }

        footer a {
            color: var(--primary);
            text-decoration: none;
        }

        footer a:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            header h1 {
                font-size: 2rem;
            }
            header p {
                font-size: 1rem;
            }
            .services-section h2 {
                font-size: 1.5rem;
            }
            .service-card {
                max-width: 100%;
            }
        }

        @media (max-width: 480px) {
            body {
                padding: 1rem;
            }
            header {
                padding: 1.5rem 0;
            }
            .services-section {
                padding: 1.5rem;
            }
            .service-card {
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Our Services</h1>
            <p>Explore What Fitness Tracker Offers You</p>
        </header>

        <section class="services-section">
            <h2>Your Path to Fitness</h2>
            <div class="services-grid">
                <div class="service-card">
                    <h3>Personal Training</h3>
                    <p>Connect with certified trainers for one-on-one sessions tailored to your goals, whether it’s weight loss, strength, or flexibility.</p>
                    <a href="trainer_login.php" class="btn">Find a Trainer</a>
                </div>
                <div class="service-card">
                    <h3>Workout Tracking</h3>
                    <p>Log your exercises, monitor progress, and get insights to optimize your fitness routine with our easy-to-use tools.</p>
                    <a href="user_register.php" class="btn">Get Started</a>
                </div>
                <div class="service-card">
                    <h3>Community Support</h3>
                    <p>Join a community of fitness enthusiasts, share your journey, and stay motivated with group challenges and forums.</p>
                    <a href="user_login.php" class="btn">Join Now</a>
                </div>
                <div class="service-card">
                    <h3>Nutrition Guidance</h3>
                    <p>Access meal plans and dietary tips from experts to complement your training and achieve a balanced lifestyle.</p>
                    <a href="user_register.php" class="btn">Learn More</a>
                </div>
            </div>
        </section>

        <footer>
            <p>© <?php echo date('Y'); ?> Fitness Tracker. All rights reserved. | <a href="contact.php">Contact Us</a></p>
        </footer>
    </div>
</body>
</html>