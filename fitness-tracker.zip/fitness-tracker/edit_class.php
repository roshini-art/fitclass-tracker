<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Database connection
include 'db.php';

// Check if class ID is provided
if (isset($_GET['id'])) {
    $class_id = (int) $_GET['id'];

    // Fetch class details
    $sql = "SELECT * FROM classes WHERE id = $class_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $class = $result->fetch_assoc();
    } else {
        echo "Class not found!";
        exit;
    }
} else {
    echo "No class ID provided!";
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_name = $_POST['class_name'];
    $description = $_POST['description'];
    $silver_price = $_POST['silver_price'];
    $gold_price = $_POST['gold_price'];
    $platinum_price = $_POST['platinum_price'];
    $silver_description = $_POST['silver_description'];
    $gold_description = $_POST['gold_description'];
    $platinum_description = $_POST['platinum_description'];

    // Update class details
    $update_sql = "UPDATE classes SET 
        class_name = '$class_name', 
        description = '$description',
        silver_price = '$silver_price',
        gold_price = '$gold_price',
        platinum_price = '$platinum_price',
        silver_description = '$silver_description',
        gold_description = '$gold_description',
        platinum_description = '$platinum_description'
        WHERE id = $class_id";

    if ($conn->query($update_sql) === TRUE) {
        echo "<script>alert('Class updated successfully!'); window.location.href='view_classes.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Class</title>
</head>
<body>

    <h1>Edit Class</h1>

    <form action="edit_class.php?id=<?= $class_id; ?>" method="POST">
        <label>Class Name:</label>
        <input type="text" name="class_name" value="<?= $class['class_name']; ?>" required><br>

        <label>Description:</label>
        <textarea name="description" required><?= $class['description']; ?></textarea><br>

        <label>Silver Price:</label>
        <input type="number" name="silver_price" value="<?= $class['silver_price']; ?>" required><br>

        <label>Gold Price:</label>
        <input type="number" name="gold_price" value="<?= $class['gold_price']; ?>" required><br>

        <label>Platinum Price:</label>
        <input type="number" name="platinum_price" value="<?= $class['platinum_price']; ?>" required><br>

        <label>Silver Description:</label>
        <textarea name="silver_description" required><?= $class['silver_description']; ?></textarea><br>

        <label>Gold Description:</label>
        <textarea name="gold_description" required><?= $class['gold_description']; ?></textarea><br>

        <label>Platinum Description:</label>
        <textarea name="platinum_description" required><?= $class['platinum_description']; ?></textarea><br>

        <input type="submit" value="Update Class">
    </form>

</body>
</html>
