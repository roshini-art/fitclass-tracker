<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Database connection
include 'db.php';

// Fetch all classes from the database
$sql = "SELECT * FROM classes";
$result = $conn->query($sql);

// Delete class functionality
if (isset($_GET['delete_id'])) {
    $delete_id = (int) $_GET['delete_id'];
    
    // Delete the class from the database
    $delete_sql = "DELETE FROM classes WHERE id = $delete_id";
    if ($conn->query($delete_sql) === TRUE) {
        echo "<script>alert('Class deleted successfully!'); window.location.href='view_classes.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Classes</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            color: #333;
            padding-top: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        .btn-view, .btn-edit, .btn-delete {
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        .btn-view {
            background-color: #28a745;
            color: white;
        }
        .btn-view:hover {
            background-color: #218838;
        }
        .btn-edit {
            background-color: #ffc107;
            color: white;
        }
        .btn-edit:hover {
            background-color: #e0a800;
        }
        .btn-delete {
            background-color: #dc3545;
            color: white;
        }
        .btn-delete:hover {
            background-color: #c82333;
        }
        td {
    padding: 10px;
    text-align: center;
}

td .btn-view,
td .btn-edit,
td .btn-delete {
    display: inline-block;
    margin: 5px; /* Add spacing between buttons */
    padding: 8px 12px;
    border-radius: 5px;
    font-size: 14px;
}

    </style>
</head>
<body>

    <h1>View Classes</h1>

    <div class="container">
        <h2>Available Classes</h2>
        
        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Class Name</th>
                        <th>Description</th>
                        <th>Silver Price</th>
                        <th>Gold Price</th>
                        <th>Platinum Price</th>
                        <th>Silver Description</th>
                        <th>Gold Description</th>
                        <th>Platinum Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['class_name']); ?></td>
                            <td><?= htmlspecialchars($row['description']); ?></td>
                            <td>₹<?= htmlspecialchars($row['silver_price']); ?></td>
                            <td>₹<?= htmlspecialchars($row['gold_price']); ?></td>
                            <td>₹<?= htmlspecialchars($row['platinum_price']); ?></td>
                            <td><?= htmlspecialchars($row['silver_description']); ?></td>
                            <td><?= htmlspecialchars($row['gold_description']); ?></td>
                            <td><?= htmlspecialchars($row['platinum_description']); ?></td>
                            <td>
    <div style="display: flex; justify-content: center; gap: 10px;">
        <a href="view_trainers.php?class_id=<?= $row['id']; ?>" class="btn-view">View Trainers</a>
        <a href="edit_class.php?id=<?= $row['id']; ?>" class="btn-edit">Edit</a>
        <a href="?delete_id=<?= $row['id']; ?>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this class?');">Delete</a>
    </div>
</td>

                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No classes available.</p>
        <?php endif; ?>
    </div>

</body>
</html>
