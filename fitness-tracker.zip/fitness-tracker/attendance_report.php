<?php
include 'db.php';

$sql = "SELECT a.attendance_date, u.full_name AS user_name, t.name AS trainer_name, a.status
        FROM attendees a
        JOIN users u ON a.user_id = u.id
        JOIN trainers t ON a.trainer_id = t.id
        ORDER BY a.attendance_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Attendance Report</title>
</head>
<body>
    <h2>Attendance Report</h2>
    <table border="1">
        <tr>
            <th>Date</th>
            <th>User</th>
            <th>Trainer</th>
            <th>Status</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['attendance_date']; ?></td>
                <td><?= $row['user_name']; ?></td>
                <td><?= $row['trainer_name']; ?></td>
                <td><?= $row['status']; ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
