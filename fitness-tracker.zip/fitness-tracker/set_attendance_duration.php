<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $booking_id = $_POST['booking_id'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Update booking with start and end date
    $sql = "UPDATE bookings SET start_date = ?, end_date = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $start_date, $end_date, $booking_id);

    if ($stmt->execute()) {
        echo "<script>alert('Attendance duration set successfully!'); window.location='admin_booking.php';</script>";
    } else {
        echo "<script>alert('Error setting duration.'); window.history.back();</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
