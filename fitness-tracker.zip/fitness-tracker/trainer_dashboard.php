<?php
session_start();

// Check if the trainer is logged in
if (!isset($_SESSION['trainer_logged_in']) || $_SESSION['trainer_logged_in'] !== true) {
    header("Location: trainer_login.php");
    exit();
}

// Database connection
include 'db.php';

// Get the logged-in trainer's ID
$trainer_id = $_SESSION['trainer_id'];

// Fetch trainer details
$sql = "SELECT * FROM trainers WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $trainer_id);
$stmt->execute();
$result = $stmt->get_result();
$trainer = $result->fetch_assoc();
$stmt->close();

// Fetch all available classes for the trainer
$class_query = "SELECT * FROM classes WHERE trainer_id = ?";
$stmt = $conn->prepare($class_query);
$stmt->bind_param("i", $trainer_id);
$stmt->execute();
$class_result = $stmt->get_result();
$classes = [];
while ($row = $class_result->fetch_assoc()) {
    $classes[] = $row;
}
$stmt->close();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trainer Dashboard</title>
    <style>
        
        body { font-family: 'Arial', sans-serif; background-color: #f4f4f9; margin: 0; padding: 0; }
        .header { background-color: #007bff; color: white; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; }
        .header h1 { margin: 0; font-size: 24px; }
        .nav-bar a { color: white; text-decoration: none; margin-left: 20px; font-size: 18px; padding: 8px 16px; background-color: #0056b3; border-radius: 5px; transition: background-color 0.3s ease; }
        .nav-bar a:hover { background-color: #003d82; }
        .content-wrapper { width: auto; margin: 20px; padding: 20px; text-align: left; border: 2px solid #ccc; border-radius: 10px; background-color: #fff; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1); }
        .trainer-details { display: flex; align-items: center; }
        .trainer-details img { width: 120px; height: 120px; border-radius: 50%; border: 2px solid #007bff; margin-right: 20px; }
        .trainer-info p { margin: 5px 0; font-size: 18px; }
        .trainer-info strong { color: #007bff; }
        body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 0;
}

.header {
    background-color: #007bff;
    color: white;
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
}

.header h1 {
    margin: 0;
    font-size: 24px;
}

.nav-bar a {
    color: white;
    text-decoration: none;
    font-size: 18px;
    padding: 8px 16px;
    background-color: #0056b3;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.nav-bar a:hover {
    background-color: #003d82;
}

.content-wrapper {
    width: 80%;
    margin: 20px auto;
    padding: 20px;
    text-align: left;
    border: 2px solid #ccc;
    border-radius: 10px;
    background-color: #fff;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.trainer-details {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
}

.trainer-details img {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    border: 2px solid #007bff;
    margin-right: 20px;
}

.trainer-info p {
    margin: 5px 0;
    font-size: 18px;
}

.trainer-info strong {
    color: #007bff;
}

/* Button container for proper alignment */
.button-container {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    margin-top: 20px;
}
/* Button container for proper alignment with more spacing */
.button-container {
    display: flex;
    flex-wrap: wrap;
    gap: 20px; /* Increased gap between buttons */
    margin-top: 20px;
    justify-content: center; /* Center the buttons */
}

/* Styling for all buttons */
.button-container a {
    display: inline-block;
    padding: 12px 20px;
    font-size: 18px;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    text-align: center;
    transition: background-color 0.3s ease;
    min-width: 220px;
    margin: 5px; /* Adds extra spacing */
}

/* Button colors */
.btn-attendance { background-color: #28a745; }
.btn-tracker { background-color: #6f42c1; }
.btn-schedule { background-color: #17a2b8; }
.btn-students { background-color: #ff9800; }
.btn-logout { background-color: #dc3545; }

/* Hover effects */
.btn-attendance:hover { background-color: #218838; }
.btn-tracker:hover { background-color: #5a32a3; }
.btn-schedule:hover { background-color: #138496; }
.btn-students:hover { background-color: #e68900; }
.btn-logout:hover { background-color: #c82333; }


/* Styling for all buttons */
.button-container a {
    display: inline-block;
    padding: 12px 20px;
    font-size: 18px;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    text-align: center;
    transition: background-color 0.3s ease;
    min-width: 200px;
}

/* Button colors */
.btn-attendance { background-color: #28a745; }
.btn-tracker { background-color: #6f42c1; }
.btn-schedule { background-color: #17a2b8; }
.btn-students { background-color: #ff9800; }
.btn-logout { background-color: #dc3545; }

/* Hover effects */
.btn-attendance:hover { background-color: #218838; }
.btn-tracker:hover { background-color: #5a32a3; }
.btn-schedule:hover { background-color: #138496; }
.btn-students:hover { background-color: #e68900; }
.btn-logout:hover { background-color: #c82333; }

       
    </style>
</head>
<body>



    <div class="header">
        <h1>Trainer Dashboard</h1>
        <!-- Add this inside the .content-wrapper div in trainer_dashboard.php -->
<!-- New Attendees Button -->
<div class="button-container">
    <a href="trainer_attendance.php" class="btn-attendance">Mark Attendance</a>
    <a href="student_fitness_tracker.php" class="btn-tracker">View Student Fitness Tracker</a>
    <a href="send_schedule.php" class="btn-schedule">Send Schedule to Users</a>
    <a href="trainer_students.php" class="btn-students">View Students</a>
    <a href="trainer_logout.php" class="btn-logout">Log Out</a>
</div>
    </div>

    <div class="content-wrapper">
        <div class="trainer-details">
            <?php if (!empty($trainer['image'])): ?>
                <img src="uploads/<?= htmlspecialchars($trainer['image']); ?>" alt="Trainer Image">
            <?php else: ?>
                <img src="default_trainer.png" alt="Default Image">
            <?php endif; ?>
            
            <div class="trainer-info">
                <p><strong>Trainer ID:</strong> <?= htmlspecialchars($trainer['id']); ?></p>
                <p><strong>Name:</strong> <?= htmlspecialchars($trainer['name']); ?></p>
                <p><strong>Specialization:</strong> <?= htmlspecialchars($trainer['specialization']); ?></p>
                <p><strong>Contact Number:</strong> <?= htmlspecialchars($trainer['contact_number']); ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($trainer['email']); ?></p>
                <p><strong>Class ID:</strong> <?= htmlspecialchars($trainer['class_id']); ?></p>
                <p><strong>Date of Birth:</strong> <?= htmlspecialchars($trainer['dob']); ?></p>
                <p><strong>Shift Timings:</strong> <?= htmlspecialchars($trainer['shift_timings']); ?></p>
            </div>
        </div>

        
        </div>

        

</body>
</html>





