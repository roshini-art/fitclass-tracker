<?php
// Database connection
$servername = "localhost";
$username = "root"; // Adjust according to your database credentials
$password = ""; // Adjust according to your database credentials
$dbname = "fitness_booking";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['submit'])) {
    // Get the form inputs
    $class_name = $_POST['class_name'];
    $description = $_POST['description'];
    $image = $_FILES['image'];

    // Handle file upload
    $target_dir = "uploads/class_img/";
    $target_file = $target_dir . basename($image["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if the file is an image
    $check = getimagesize($image["tmp_name"]);
    if ($check === false) {
        echo "File is not an image.";
        exit;
    }

    // Check if the file already exists
    if (file_exists($target_file)) {
        echo "Sorry, the file already exists.";
        exit;
    }

    // Check file size (optional)
    if ($image["size"] > 500000) {
        echo "Sorry, your file is too large.";
        exit;
    }

    // Allow certain file formats (optional)
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        exit;
    }

    // Upload the file
    if (move_uploaded_file($image["tmp_name"], $target_file)) {
        // Insert the class data into the database along with the image path
        $sql = "INSERT INTO classes (class_name, description, image_path) 
                VALUES ('$class_name', '$description', '$target_file')";

        if ($conn->query($sql) === TRUE) {
            echo "Class added successfully.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

$conn->close();
?>
