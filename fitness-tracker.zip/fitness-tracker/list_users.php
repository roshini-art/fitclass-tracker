<?php
session_start();
include 'db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

// Get filter parameter
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

// Determine query based on filter
if ($filter == "accepted") {
    $sql = "SELECT u.*, b.package_type, b.price FROM users u 
            JOIN bookings b ON u.id = b.user_id 
            WHERE b.payment_status = 'Accepted'";
    $title = "Accepted Users";
} elseif ($filter == "rejected") {
    $sql = "SELECT u.*, b.package_type, b.price FROM users u 
            JOIN bookings b ON u.id = b.user_id 
            WHERE b.payment_status = 'Rejected'";
    $title = "Rejected Users";
} elseif ($filter == "pending") {
    $sql = "SELECT u.*, b.package_type, b.price FROM users u 
            JOIN bookings b ON u.id = b.user_id 
            WHERE b.payment_status = 'Pending'";
    $title = "Pending Users";
} else {
    $sql = "SELECT u.*, b.package_type, b.price FROM users u 
            LEFT JOIN bookings b ON u.id = b.user_id";
    $title = "Total Users";
}

// Fetch users
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            text-align: center;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 90%;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            background-color: #007bff;
            color: white;
            padding: 15px;
            font-size: 24px;
            font-weight: bold;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .btn-back {
            padding: 10px 15px;
            margin: 10px;
            cursor: pointer;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            background-color: red;
        }
    </style>
</head>
<body>

    <div class="header"><?= $title; ?></div>

    <div class="container">
        <a href="admin_bookings.php" class="btn-back">Back to Admin Bookings</a>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Full Name</th>
                    <th>Phone</th>
                    <th>Date of Birth</th>
                    <th>Package</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']); ?></td>
                        <td><?= htmlspecialchars($row['username']); ?></td>
                        <td><?= htmlspecialchars($row['email']); ?></td>
                        <td><?= htmlspecialchars($row['address']); ?></td>
                        <td><?= htmlspecialchars($row['full_name']); ?></td>
                        <td><?= htmlspecialchars($row['phone']); ?></td>
                        <td><?= htmlspecialchars($row['dob']); ?></td>
                        <td><?= !empty($row['package_type']) ? ucfirst(htmlspecialchars($row['package_type'])) : 'N/A'; ?></td>
                        <td><?= !empty($row['price']) ? '$' . htmlspecialchars($row['price']) : 'N/A'; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

</body>
</html>

<?php
$conn->close();
?>
