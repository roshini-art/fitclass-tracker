<?php
// Database connection
include 'db.php';

// Check if booking_id and action are provided
if (!isset($_GET['booking_id']) || !isset($_GET['action'])) {
    die("Invalid request.");
}

$booking_id = intval($_GET['booking_id']);
$action = $_GET['action'];
$allowed_actions = ['accept', 'reject', 'complete'];

if (!in_array($action, $allowed_actions)) {
    die("Invalid action.");
}

// Determine the new status based on action
$new_status = '';
if ($action == 'accept') {
    $new_status = 'Accepted';
} elseif ($action == 'reject') {
    $new_status = 'Rejected';
} elseif ($action == 'complete') {
    $new_status = 'Completed';
}

// Update booking status
$sql_update = "UPDATE bookings SET payment_status = ? WHERE id = ?";
$stmt = $conn->prepare($sql_update);
if (!$stmt) {
    die("Error preparing SQL query: " . $conn->error);
}

$stmt->bind_param("si", $new_status, $booking_id);

if ($stmt->execute()) {
    echo "<script>alert('Booking status updated successfully!'); window.location.href='admin_bookings.php';</script>";
} else {
    echo "Error updating booking: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
