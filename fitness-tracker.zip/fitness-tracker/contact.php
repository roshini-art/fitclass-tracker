<?php
session_start();

// Database connection
include 'db.php';

// Initialize variables
$errors = [];
$success_message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $message = isset($_POST['message']) ? trim($_POST['message']) : '';

    // Validation
    if (empty($name)) {
        $errors[] = "Name is required.";
    } elseif (!preg_match("/^[a-zA-Z\s]{2,50}$/", $name)) {
        $errors[] = "Name must be 2-50 characters, letters and spaces only.";
    }

    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (empty($message)) {
        $errors[] = "Message is required.";
    } elseif (strlen($message) < 10 || strlen($message) > 500) {
        $errors[] = "Message must be between 10 and 500 characters.";
    }

    // If no errors, save to database
    if (empty($errors)) {
        $sql = "INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sss", $name, $email, $message);
            if ($stmt->execute()) {
                $success_message = "Thank you for contacting us! We’ll get back to you soon.";
                $name = $email = $message = ""; // Clear form
            } else {
                $errors[] = "Error saving message: " . $conn->error;
            }
            $stmt->close();
        } else {
            $errors[] = "Error preparing statement: " . $conn->error;
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Fitness Tracker</title>
    <style>
        :root {
            --primary: #007bff; /* Blue for accents */
            --primary-dark: #0056b3; /* Darker blue for hover */
            --error: #dc3545; /* Red for errors */
            --success: #28a745; /* Green for success */
            --bg: #f4f4f9; /* Light gray background */
            --white: #fff; /* White for sections */
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            --text: #333; /* Dark text color */
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
            padding: 2rem;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        header {
            text-align: center;
            padding: 2rem 0;
            background: var(--white);
            border-radius: 8px;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }

        header h1 {
            color: var(--primary);
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }

        header p {
            font-size: 1.2rem;
            color: #666;
        }

        .contact-section {
            display: flex;
            flex-wrap: wrap;
            gap: 2rem;
            background: var(--white);
            padding: 2rem;
            border-radius: 8px;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }

        .contact-form, .contact-info {
            flex: 1;
            min-width: 300px;
        }

        .contact-form h2, .contact-info h2 {
            color: var(--primary);
            font-size: 1.75rem;
            margin-bottom: 1rem;
        }

        .contact-form form {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .contact-form label {
            font-weight: bold;
            color: var(--text);
        }

        .contact-form input, .contact-form textarea {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        .contact-form textarea {
            resize: vertical;
            min-height: 100px;
        }

        .contact-form input:focus, .contact-form textarea:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
        }

        .contact-form button {
            background: var(--primary);
            color: var(--white);
            padding: 0.75rem;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .contact-form button:hover {
            background: var(--primary-dark);
        }

        .error-message, .success-message {
            text-align: center;
            margin-bottom: 1rem;
            font-size: 0.9rem;
            font-weight: bold;
        }

        .error-message {
            color: var(--error);
        }

        .success-message {
            color: var(--success);
        }

        .contact-info p {
            margin-bottom: 0.75rem;
            font-size: 1rem;
        }

        .contact-info a {
            color: var(--primary);
            text-decoration: none;
        }

        .contact-info a:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }

        footer {
            text-align: center;
            padding: 1rem 0;
            font-size: 0.9rem;
            color: #666;
        }

        footer a {
            color: var(--primary);
            text-decoration: none;
        }

        footer a:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            header h1 {
                font-size: 2rem;
            }
            header p {
                font-size: 1rem;
            }
            .contact-form h2, .contact-info h2 {
                font-size: 1.5rem;
            }
        }

        @media (max-width: 480px) {
            body {
                padding: 1rem;
            }
            header, .contact-section {
                padding: 1.5rem;
            }
            .contact-form input, .contact-form textarea, .contact-form button {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Contact Us</h1>
            <p>We’d Love to Hear From You</p>
        </header>

        <section class="contact-section">
            <div class="contact-form">
                <h2>Send Us a Message</h2>
                <?php if (!empty($errors)): ?>
                    <div class="error-message">
                        <?php foreach ($errors as $error): ?>
                            <p><?= htmlspecialchars($error) ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php elseif (!empty($success_message)): ?>
                    <div class="success-message"><?= htmlspecialchars($success_message) ?></div>
                <?php endif; ?>
                <form method="POST" action="contact.php">
                    <label for="name">Name</label>
                    <input type="text" name="name" id="name" value="<?= htmlspecialchars(isset($name) ? $name : '') ?>" required>

                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" value="<?= htmlspecialchars(isset($email) ? $email : '') ?>" required>

                    <label for="message">Message</label>
                    <textarea name="message" id="message" required><?= htmlspecialchars(isset($message) ? $message : '') ?></textarea>

                    <button type="submit">Send Message</button>
                </form>
            </div>

            <div class="contact-info">
                <h2>Get in Touch</h2>
                <p><strong>Email:</strong> <a href="mailto:support@fitnesstracker.com">support@fitnesstracker.com</a></p>
                <p><strong>Phone:</strong> +1 (555) 123-4567</p>
                <p><strong>Address:</strong> 123 Fitness Lane, Wellness City, FC 45678</p>
                <p><strong>Hours:</strong> Mon-Fri, 9 AM - 5 PM</p>
            </div>
        </section>

        <footer>
            <p>© <?php echo date('Y'); ?> Fitness Tracker. All rights reserved. | <a href="services.php">Our Services</a></p>
        </footer>
    </div>
</body>
</html>