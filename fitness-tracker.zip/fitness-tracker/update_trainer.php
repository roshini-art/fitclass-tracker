<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Database connection
include 'db.php';

// Get the trainer ID from the URL
$trainer_id = isset($_GET['trainer_id']) ? $_GET['trainer_id'] : 0;

// Fetch trainer details for the given trainer ID
$sql = "SELECT * FROM trainers WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $trainer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $trainer = $result->fetch_assoc();
} else {
    echo "<script>alert('Trainer not found!'); window.location.href='view_classes.php';</script>";
    exit();
}

// Update trainer details when the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $specialization = $_POST['specialization'];
    $contact_number = $_POST['contact_number'];
    $email = $_POST['email'];
    $dob = $_POST['dob']; // Get the date of birth (dob) from the form

    // Check if a new image is uploaded
    if (isset($_FILES['image']['name']) && $_FILES['image']['name'] !== "") {
        $image_name = $_FILES['image']['name'];
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($image_name);

        // Move uploaded file to the target directory
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            // Update the trainer with the new image and dob
            $update_sql = "UPDATE trainers SET name = ?, specialization = ?, contact_number = ?, email = ?, dob = ?, image = ? WHERE id = ?";
            $stmt_update = $conn->prepare($update_sql);
            $stmt_update->bind_param("ssssssi", $name, $specialization, $contact_number, $email, $dob, $image_name, $trainer_id);
        } else {
            echo "<script>alert('Failed to upload image.');</script>";
        }
    } else {
        // Update the trainer without changing the image and with dob
        $update_sql = "UPDATE trainers SET name = ?, specialization = ?, contact_number = ?, email = ?, dob = ? WHERE id = ?";
        $stmt_update = $conn->prepare($update_sql);
        $stmt_update->bind_param("sssssi", $name, $specialization, $contact_number, $email, $dob, $trainer_id);
    }

    if ($stmt_update->execute()) {
        echo "<script>alert('Trainer updated successfully!'); window.location.href='view_trainers.php?class_id={$trainer['class_id']}';</script>";
    } else {
        echo "<script>alert('Failed to update trainer.');</script>";
    }
    $stmt_update->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Trainer</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-top: 10px;
            font-weight: bold;
        }
        input[type="text"], input[type="email"], input[type="file"], input[type="date"] {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            margin-top: 20px;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Update Trainer</h1>
        <form method="POST" enctype="multipart/form-data">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?= $trainer['name']; ?>" required>

            <label for="specialization">Specialization:</label>
            <input type="text" id="specialization" name="specialization" value="<?= $trainer['specialization']; ?>" required>

            <label for="contact_number">Contact Number:</label>
            <input type="text" id="contact_number" name="contact_number" value="<?= $trainer['contact_number']; ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?= $trainer['email']; ?>" required>

            <label for="dob">Date of Birth:</label>
            <input type="date" id="dob" name="dob" value="<?= $trainer['dob']; ?>" required>

            <label for="image">Image (optional):</label>
            <input type="file" id="image" name="image">
            <p>Current Image:</p>
            <img src="uploads/<?= $trainer['image']; ?>" alt="Trainer Image" width="100" height="100">

            <button type="submit">Update Trainer</button>
        </form>
    </div>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
