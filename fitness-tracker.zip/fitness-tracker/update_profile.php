<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database connection
include 'db.php';

// Initialize error message variable
$error_message = "";

// Check if the user is logged in
if (!isset($_SESSION['user_logged_in']) || !$_SESSION['user_logged_in']) {
    header("Location: login.php");
    exit();
}

// Fetch current user details
$user_id = $_SESSION['user_id'];
$sql = "SELECT username, email, phone, address, dob, full_name FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Error preparing query: " . $conn->error);
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    die("User not found.");
}

$stmt->bind_result($current_username, $current_email, $current_phone, $current_address, $current_dob, $current_full_name);
$stmt->fetch();
$stmt->close();

// Update user details if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get user input
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $dob = $_POST['dob']; // Date of Birth
    $full_name = trim($_POST['full_name']); // Full Name

    // Validate input
    if (empty($username) || empty($email) || empty($phone) || empty($address) || empty($dob) || empty($full_name)) {
        $error_message = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format.";
    } elseif (!preg_match("/^[0-9]{10}$/", $phone)) {
        $error_message = "Invalid phone number. Please enter a 10-digit number.";
    } else {
        // Check if new email already exists
        $sql = "SELECT id FROM users WHERE email = ? AND id != ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Error preparing query: " . $conn->error);
        }

        $stmt->bind_param("si", $email, $user_id);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error_message = "Email is already registered.";
            $stmt->close();
        } else {
            // Update user in the database
            $sql = "UPDATE users SET username = ?, email = ?, phone = ?, address = ?, dob = ?, full_name = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                die("Error preparing update query: " . $conn->error);
            }

            $stmt->bind_param("ssssssi", $username, $email, $phone, $address, $dob, $full_name, $user_id);
            if ($stmt->execute()) {
                // Update session username if it was changed
                $_SESSION['username'] = $username;

                // Redirect to the profile page or any other page
                header("Location: profile.php");
                exit();
            } else {
                $error_message = "Error updating user: " . $conn->error;
            }
            $stmt->close();
        }
    }
}
$conn->close();
?>

<!-- HTML Form for updating profile -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .profile-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        h2 {
            text-align: center;
        }
        label {
            display: block;
            margin-top: 10px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .btn {
            width: 100%;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 15px;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="profile-container">
    <h2>Update Profile</h2>

    <?php if (!empty($error_message)): ?>
        <div class="error-message"><?= $error_message; ?></div>
    <?php endif; ?>

    <form method="POST" action="update_profile.php">
        <label for="username">Username</label>
        <input type="text" name="username" id="username" value="<?= htmlspecialchars($current_username); ?>" required>

        <label for="email">Email</label>
        <input type="email" name="email" id="email" value="<?= htmlspecialchars($current_email); ?>" required>

        <label for="full_name">Full Name</label>
        <input type="text" name="full_name" id="full_name" value="<?= htmlspecialchars($current_full_name); ?>" required>

        <label for="phone">Phone Number</label>
        <input type="text" name="phone" id="phone" value="<?= htmlspecialchars($current_phone); ?>" required>

        <label for="address">Address</label>
        <input type="text" name="address" id="address" value="<?= htmlspecialchars($current_address); ?>" required>

        <label for="dob">Date of Birth</label>
        <input type="date" name="dob" id="dob" value="<?= htmlspecialchars($current_dob); ?>" required>

        <button type="submit" class="btn">Update Profile</button>
    </form>
</div>

</body>
</html>
