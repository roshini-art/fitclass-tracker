<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Database connection
include 'db.php';

// Fetch total classes and trainers count
$total_classes = $conn->query("SELECT COUNT(*) AS count FROM classes")->fetch_assoc()['count'];
$total_trainers = $conn->query("SELECT COUNT(*) AS count FROM trainers")->fetch_assoc()['count'];

// Initialize messages
$success_message = "";
$error_message = "";

// Handle Add Trainer form submission
if (isset($_POST['add_trainer'])) {
    $trainer_name = $_POST['trainer_name'];
    $specialization = $_POST['specialization'];
    $contact_number = $_POST['contact_number'];
    $email = $_POST['email'];
    $trainer_image = $_FILES['trainer_image']['name'];
    $class_id = $_POST['class_id'];
    $dob = $_POST['dob'];
    $shift_timings = $_POST['shift_timings'];

    // Generate a unique Trainer ID
    $result = $conn->query("SELECT MAX(trainer_id) AS max_id FROM trainers");
    $row = $result->fetch_assoc();
    $next_trainer_id = isset($row['max_id']) ? $row['max_id'] + 1 : 1;

    // Save trainer image (if uploaded)
    if (!empty($trainer_image)) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($trainer_image);
        move_uploaded_file($_FILES['trainer_image']['tmp_name'], $target_file);
    }

    // Insert new trainer into the database
    $sql = "INSERT INTO trainers (trainer_id, name, specialization, contact_number, email, class_id, image, dob, shift_timings) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("issssssss", $next_trainer_id, $trainer_name, $specialization, $contact_number, $email, $class_id, $trainer_image, $dob, $shift_timings);

        if ($stmt->execute()) {
            $success_message = "Trainer added successfully! ID: " . $stmt->insert_id;
        } else {
            $error_message = "Error adding trainer: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $error_message = "Error preparing statement: " . $conn->error;
    }
}

// Handle Add Class form submission
if (isset($_POST['add_class'])) {
    $class_name = $_POST['class_name'];
    $description = $_POST['description'];
    $class_image = $_FILES['class_image']['name'];

    $platinum_price = $_POST['platinum_price'];
    $gold_price = $_POST['gold_price'];
    $silver_price = $_POST['silver_price'];

    $platinum_duration = $_POST['platinum_duration'];
    $gold_duration = $_POST['gold_duration'];
    $silver_duration = $_POST['silver_duration'];

    $platinum_description = $_POST['platinum_description'];
    $gold_description = $_POST['gold_description'];
    $silver_description = $_POST['silver_description'];

    if (!empty($class_image)) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($class_image);
        move_uploaded_file($_FILES['class_image']['tmp_name'], $target_file);
    }

    $sql = "INSERT INTO classes (class_name, description, image, 
                                 platinum_price, gold_price, silver_price, 
                                 platinum_duration, gold_duration, silver_duration, 
                                 platinum_description, gold_description, silver_description) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("sssdddiiisss", $class_name, $description, $class_image, 
                                            $platinum_price, $gold_price, $silver_price, 
                                            $platinum_duration, $gold_duration, $silver_duration, 
                                            $platinum_description, $gold_description, $silver_description);

        if ($stmt->execute()) {
            $class_id = $conn->insert_id;
            $success_message = "Class added successfully! Class ID: " . $class_id;
        } else {
            $error_message = "Error adding class: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $error_message = "Error preparing statement: " . $conn->error;
    }
}



// Fetch classes for the dropdown
$classes_result = $conn->query("SELECT id, class_name FROM classes");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #f4f4f9;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }

        /* Navigation */
        nav {
            text-align: center;
            margin-bottom: 30px;
        }

        nav a {
            color: #007bff;
            text-decoration: none;
            margin: 0 15px;
            font-weight: bold;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #0056b3;
        }

        /* Container */
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Dashboard Stats */
        .dashboard-stats {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-box {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 200px;
        }

        .stat-box h3 {
            color: #007bff;
            font-size: 28px;
            margin-bottom: 10px;
        }

        .stat-box p {
            font-size: 16px;
            color: #666;
        }

        /* Messages */
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Sections */
        .section {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .section h2 {
            color: #007bff;
            margin-bottom: 20px;
            text-align: center;
        }

        /* Form Styling */
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
            max-width: 500px;
            margin: 0 auto;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"],
        input[type="tel"],
        input[type="email"],
        input[type="date"],
        input[type="number"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="tel"]:focus,
        input[type="email"]:focus,
        input[type="date"]:focus,
        input[type="number"]:focus,
        textarea:focus,
        select:focus {
            border-color: #007bff;
            outline: none;
        }

        textarea {
            height: 100px;
            resize: vertical;
        }

        input[type="file"] {
            padding: 5px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .dashboard-stats {
                flex-direction: column;
                align-items: center;
            }

            .stat-box {
                width: 100%;
                max-width: 300px;
            }

            nav a {
                display: block;
                margin: 10px 0;
            }

            form {
                max-width: 100%;
            }
        }
    </style>
</head>
</head>
<body>

<h1>Admin Dashboard</h1>

<!-- Navigation Links -->
<nav>
    <a href="#add-trainer-section">Add Trainer</a>
    <a href="#add-class-section">Add Class</a>
    <a href="view_classes.php">View Classes</a>
</nav>

<div class="container">
    <div class="dashboard-stats">
        <div class="stat-box">
            <h3><?php echo $total_trainers; ?></h3>
            <p>Total Trainers</p>
        </div>
        <div class="stat-box">
            <h3><?php echo $total_classes; ?></h3>
            <p>Total Classes</p>
        </div>
    </div>

    <!-- Success/Error Messages -->
    <?php if ($success_message) { ?>
        <div class="message success-message"><?php echo $success_message; ?></div>
    <?php } ?>
    <?php if ($error_message) { ?>
        <div class="message error-message"><?php echo $error_message; ?></div>
    <?php } ?>

    <!-- Add Trainer Section -->
    <div class="section" id="add-trainer-section">
        <h2>Add Trainer</h2>
        <form method="POST" enctype="multipart/form-data">
            <label for="trainer_name">Trainer Name:</label>
            <input type="text" name="trainer_name" required>

            <label for="specialization">Specialization:</label>
            <input type="text" name="specialization" required>

            <label for="contact_number">Contact Number:</label>
            <input type="tel" name="contact_number" required>

            <label for="email">Email:</label>
            <input type="email" name="email" required>

            <label for="dob">Date of Birth:</label>
            <input type="date" name="dob" required>

            <label for="trainer_image">Trainer Image:</label>
            <input type="file" name="trainer_image">

            <label for="class_id">Class:</label>
            <select name="class_id" required>
                <?php while ($class = $classes_result->fetch_assoc()) { ?>
                    <option value="<?php echo $class['id']; ?>"><?php echo $class['class_name']; ?></option>
                <?php } ?>
            </select>

            <label for="shift_timings">Shift Timings:</label>
            <textarea name="shift_timings" required></textarea>

            <input type="submit" name="add_trainer" value="Add Trainer">
        </form>
    </div>

   <!-- Add Class Section -->
<div class="section" id="add-class-section">
    <h2>Add Class</h2>
    <form method="POST" enctype="multipart/form-data">
        <label for="class_name">Class Name:</label>
        <input type="text" name="class_name" required>

        <label for="description">Description:</label>
        <textarea name="description" required></textarea>

        <label for="class_image">Class Image:</label>
        <input type="file" name="class_image">

        <label for="platinum_price">Platinum Price:</label>
        <input type="number" name="platinum_price" step="0.01" required>

        <label for="gold_price">Gold Price:</label>
        <input type="number" name="gold_price" step="0.01" required>

        <label for="silver_price">Silver Price:</label>
        <input type="number" name="silver_price" step="0.01" required>

        <label for="platinum_description">Platinum Package Description:</label>
        <textarea name="platinum_description" required></textarea>

        <label for="gold_description">Gold Package Description:</label>
        <textarea name="gold_description" required></textarea>

        <label for="silver_description">Silver Package Description:</label>
        <textarea name="silver_description" required></textarea>

        <label for="platinum_duration">Platinum Package Duration (Days):</label>
    <input type="number" name="platinum_duration" required>

    <label for="gold_duration">Gold Package Duration (Days):</label>
    <input type="number" name="gold_duration" required>

    <label for="silver_duration">Silver Package Duration (Days):</label>
    <input type="number" name="silver_duration" required>

        <input type="submit" name="add_class" value="Add Class">
    </form>
</div>
</div>

</body>
</html>
