<?php
session_start();
include 'db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

// Fetch total users
$sql_total_users = "SELECT COUNT(*) AS total_users FROM users";
$result = $conn->query($sql_total_users);
$total_users = ($result && ($row = $result->fetch_assoc())) ? (int)$row['total_users'] : 0;

// Fetch new users this month
$sql_new_users = "SELECT COUNT(*) AS new_users FROM users WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())";
$result = $conn->query($sql_new_users);
$new_users = ($result && ($row = $result->fetch_assoc())) ? (int)$row['new_users'] : 0;

// Fetch total trainers
$sql_total_trainers = "SELECT COUNT(*) AS total_trainers FROM trainers";
$result = $conn->query($sql_total_trainers);
$total_trainers = ($result && ($row = $result->fetch_assoc())) ? (int)$row['total_trainers'] : 0;

// Fetch total bookings
$sql_total_bookings = "SELECT COUNT(*) AS total_bookings FROM bookings";
$result = $conn->query($sql_total_bookings);
$total_bookings = ($result && ($row = $result->fetch_assoc())) ? (int)$row['total_bookings'] : 0;

// Fetch pending bookings
$sql_pending_bookings = "SELECT COUNT(*) AS pending_bookings FROM bookings WHERE payment_status = 'Pending'";
$result = $conn->query($sql_pending_bookings);
$pending_bookings = ($result && ($row = $result->fetch_assoc())) ? (int)$row['pending_bookings'] : 0;

// Fetch total payments (from payments table)
$sql_payments = "SELECT SUM(amount) AS total_payments FROM payments";
$result = $conn->query($sql_payments);
$total_payments = ($result && ($row = $result->fetch_assoc()) && isset($row['total_payments'])) ? (float)$row['total_payments'] : 0.0;

// Fetch total accepted booking payments
$sql_accepted_payments = "SELECT SUM(price) AS total_accepted_payments FROM bookings WHERE payment_status = 'Accepted'";
$result = $conn->query($sql_accepted_payments);
$total_accepted_payments = ($result && ($row = $result->fetch_assoc()) && isset($row['total_accepted_payments'])) ? (float)$row['total_accepted_payments'] : 0.0;

// Fetch total revenue this month for accepted bookings
$sql_revenue_this_month = "SELECT SUM(price) AS revenue_this_month FROM bookings WHERE MONTH(start_date) = MONTH(CURRENT_DATE()) AND YEAR(start_date) = YEAR(CURRENT_DATE()) AND payment_status = 'Accepted'";
$result = $conn->query($sql_revenue_this_month);
$revenue_this_month = ($result && ($row = $result->fetch_assoc()) && isset($row['revenue_this_month'])) ? (float)$row['revenue_this_month'] : 0.0;

// Fetch total attendance
$sql_attendance = "SELECT COUNT(*) AS total_attendance FROM trainer_attendance WHERE status = 'Present'";
$result = $conn->query($sql_attendance);
$total_attendance = ($result && ($row = $result->fetch_assoc())) ? (int)$row['total_attendance'] : 0;

// Fetch total classes
$sql_total_classes = "SELECT COUNT(*) AS total_classes FROM classes";
$result = $conn->query($sql_total_classes);
$total_classes = ($result && ($row = $result->fetch_assoc())) ? (int)$row['total_classes'] : 0;

// Fetch active bookings this month
$sql_active_bookings = "SELECT COUNT(*) AS active_bookings FROM bookings WHERE MONTH(start_date) = MONTH(CURRENT_DATE()) AND YEAR(start_date) = YEAR(CURRENT_DATE()) AND payment_status = 'Accepted'";
$result = $conn->query($sql_active_bookings);
$active_bookings = ($result && ($row = $result->fetch_assoc())) ? (int)$row['active_bookings'] : 0;

// Fetch trainer attendance this month
$sql_attendance_this_month = "SELECT COUNT(*) AS attendance_this_month FROM trainer_attendance WHERE status = 'Present' AND MONTH(date) = MONTH(CURRENT_DATE()) AND YEAR(date) = YEAR(CURRENT_DATE())";
$result = $conn->query($sql_attendance_this_month);
$attendance_this_month = ($result && ($row = $result->fetch_assoc())) ? (int)$row['attendance_this_month'] : 0;

// Fetch pending payments amount
$sql_pending_payments = "SELECT SUM(price) AS pending_payments FROM bookings WHERE payment_status = 'Pending'";
$result = $conn->query($sql_pending_payments);
$pending_payments = ($result && ($row = $result->fetch_assoc()) && isset($row['pending_payments'])) ? (float)$row['pending_payments'] : 0.0;

// Fetch top user by bookings
$sql_top_user = "SELECT u.full_name, COUNT(b.id) AS booking_count 
                 FROM users u 
                 LEFT JOIN bookings b ON u.id = b.user_id 
                 GROUP BY u.id, u.full_name 
                 ORDER BY booking_count DESC 
                 LIMIT 1";
$result = $conn->query($sql_top_user);
$top_user = ($result && ($row = $result->fetch_assoc())) ? $row : null;

// Fetch trainer performance with filter and monthly revenue
$selected_month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$sql_trainer_performance = "SELECT 
                            t.name, 
                            COUNT(b.id) AS total_bookings, 
                            COUNT(DISTINCT b.user_id) AS unique_users, 
                            SUM(CASE WHEN b.payment_status = 'Accepted' 
                                    AND DATE_FORMAT(b.start_date, '%Y-%m') = ? 
                                    THEN 1 ELSE 0 END) AS accepted_bookings_month,
                            SUM(CASE WHEN b.payment_status = 'Accepted' 
                                    AND DATE_FORMAT(b.start_date, '%Y-%m') = ? 
                                    THEN b.price ELSE 0 END) AS monthly_revenue,
                            SUM(CASE WHEN b.payment_status = 'Accepted' THEN b.price ELSE 0 END) AS total_revenue
                            FROM trainers t 
                            LEFT JOIN bookings b ON t.id = b.trainer_id 
                            GROUP BY t.id, t.name 
                            ORDER BY total_bookings DESC";
$stmt = $conn->prepare($sql_trainer_performance);
$stmt->bind_param("ss", $selected_month, $selected_month); // Two params for both conditions
$stmt->execute();
$trainer_performance_result = $stmt->get_result();
$trainer_performance = [];
$top_trainer = null;
while ($row = $trainer_performance_result->fetch_assoc()) {
    $trainer_performance[] = $row;
    if (!$top_trainer || $row['total_bookings'] > $top_trainer['total_bookings']) {
        $top_trainer = $row;
    }
}
$stmt->close();

// Fetch user activity (active users per month, last 12 months)
$user_activity = [];
for ($i = 11; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $sql = "SELECT COUNT(DISTINCT b.user_id) AS active_users 
            FROM bookings b 
            WHERE DATE_FORMAT(b.start_date, '%Y-%m') = '$month'";
    $result = $conn->query($sql);
    $user_activity[$month] = ($result && ($row = $result->fetch_assoc())) ? (int)$row['active_users'] : 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Reports Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
        body { background: #f4f4f4; padding: 20px; }
        .container { width: 95%; max-width: 1200px; margin: 0 auto; background: #fff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 20px; }
        .header { background: #007bff; color: #fff; padding: 15px; font-size: 24px; border-radius: 8px 8px 0 0; text-align: center; }
        .card-container { display: flex; flex-wrap: wrap; justify-content: space-evenly; gap: 15px; margin: 20px 0; }
        .card { flex: 1 1 200px; max-width: 220px; padding: 20px; background: #007bff; color: #fff; border-radius: 8px; text-align: center; }
        .card h3 { margin-bottom: 10px; font-size: 18px; }
        .card p { font-size: 20px; font-weight: bold; }
        .card-btn { flex: 1 1 200px; max-width: 220px; padding: 20px; background: #28a745; color: #fff; border-radius: 8px; text-align: center; cursor: pointer; }
        .card-btn h3 { margin-bottom: 10px; font-size: 18px; }
        .card-btn p { font-size: 20px; font-weight: bold; }
        .btn { padding: 10px 20px; cursor: pointer; border-radius: 5px; border: none; font-size: 16px; color: #fff; margin: 5px; background: #17a2b8; }
        .btn:hover { background: #138496; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: center; }
        th { background: #007bff; color: #fff; font-weight: bold; }
        td { background: #fafafa; }
        h2 { color: #007bff; text-align: center; margin: 30px 0; font-size: 24px; }
        .section { margin-bottom: 40px; }
        .filter { text-align: center; margin: 20px 0; }
        .filter select { padding: 8px; font-size: 16px; border-radius: 5px; }
    </style>
</head>
<body>

<div class="header">📊 Admin Reports Dashboard</div>

<div class="container">
    <!-- Summary Cards -->
    <div class="card-container">
        <div class="card"><h3>Total Users</h3><p><?= $total_users; ?></p></div>
        <div class="card"><h3>New Users (This Month)</h3><p><?= $new_users; ?></p></div>
        <div class="card"><h3>Total Trainers</h3><p><?= $total_trainers; ?></p></div>
        <div class="card"><h3>Total Classes</h3><p><?= $total_classes; ?></p></div>
        <div class="card"><h3>Pending Bookings</h3><p><?= $pending_bookings; ?></p></div>
        <div class="card"><h3>Active Bookings (This Month)</h3><p><?= $active_bookings; ?></p></div>
        <div class="card"><h3>Total Accepted Payments</h3><p>₹<?= number_format($total_accepted_payments, 2); ?></p></div>
        <div class="card"><h3>Revenue (This Month)</h3><p>₹<?= number_format($revenue_this_month, 2); ?></p></div>
        <div class="card"><h3>Pending Payments</h3><p>₹<?= number_format($pending_payments, 2); ?></p></div>
        <div class="card"><h3>Total Attendance</h3><p><?= $total_attendance; ?></p></div>
        <div class="card"><h3>Attendance (This Month)</h3><p><?= $attendance_this_month; ?></p></div>
        <div class="card-btn" onclick="window.location.href='report_bookings.php'">
            <h3>View Bookings</h3><p><?= $total_bookings; ?></p>
        </div>
    </div>

    <!-- Trainer Performance Table with Filter -->
    <div class="section">
        <h2>Trainer Performance</h2>
        <div class="filter">
            <form method="GET">
                <label for="month">Filter by Month: </label>
                <select name="month" id="month" onchange="this.form.submit()">
                    <?php for ($i = 11; $i >= 0; $i--): ?>
                        <?php $month = date('Y-m', strtotime("-$i months")); ?>
                        <option value="<?= $month; ?>" <?= $month === $selected_month ? 'selected' : ''; ?>><?= date('F Y', strtotime($month)); ?></option>
                    <?php endfor; ?>
                </select>
            </form>
        </div>
        <table>
            <tr>
                <th>Trainer Name</th>
                <th>Total Bookings</th>
                <th>Unique Users</th>
                <th>Accepted Bookings (Selected Month)</th>
                <th>Revenue (Selected Month)</th>
                <th>Total Revenue</th>
            </tr>
            <?php foreach ($trainer_performance as $trainer): ?>
                <tr>
                    <td><?= htmlspecialchars($trainer['name']); ?></td>
                    <td><?= $trainer['total_bookings']; ?></td>
                    <td><?= $trainer['unique_users']; ?></td>
                    <td><?= $trainer['accepted_bookings_month']; ?></td>
                    <td>₹<?= number_format($trainer['monthly_revenue'], 2); ?></td>
                    <td>₹<?= number_format($trainer['total_revenue'], 2); ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>

    <!-- Top Performing Trainer -->
    <?php if ($top_trainer): ?>
        <div class="section">
            <h2>Top Performing Trainer</h2>
            <div style="text-align: center; margin: 20px 0;">
                <p><strong><?= htmlspecialchars($top_trainer['name']); ?></strong> with <?= $top_trainer['total_bookings']; ?> total bookings and ₹<?= number_format($top_trainer['total_revenue'], 2); ?> total revenue</p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Top User by Bookings -->
    <?php if ($top_user): ?>
        <div class="section">
            <h2>Top User by Bookings</h2>
            <div style="text-align: center; margin: 20px 0;">
                <p><strong><?= htmlspecialchars($top_user['full_name']); ?></strong> with <?= $top_user['booking_count']; ?> bookings</p>
            </div>
        </div>
    <?php endif; ?>

    <!-- User Activity Summary -->
    <div class="section">
        <h2>User Activity Summary (Last 12 Months)</h2>
        <table>
            <tr><th>Month</th><th>Active Users</th></tr>
            <?php foreach ($user_activity as $month => $count): ?>
                <tr>
                    <td><?= $month; ?></td>
                    <td><?= $count; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>

    <!-- Export Button -->
    <div style="text-align: center; margin: 30px 0;">
        <button class="btn" onclick="window.location.href='export_reports.php'">📥 Export All Reports</button>
    </div>
</div>

</body>
</html>