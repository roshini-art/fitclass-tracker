<?php
session_start();
include 'db.php'; // Assumes db.php only provides $conn

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

// Default filters
$where = "1"; // Base condition for WHERE clause
$order_by = "b.created_at DESC"; // Default sorting
$limit = 10; // Results per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page
$offset = ($page - 1) * $limit; // Calculate offset for pagination

// Apply filters based on GET parameters
if (isset($_GET['start_date']) && isset($_GET['end_date']) && !empty($_GET['start_date']) && !empty($_GET['end_date'])) {
    $start_date = $conn->real_escape_string($_GET['start_date']);
    $end_date = $conn->real_escape_string($_GET['end_date']);
    $where .= " AND b.start_date BETWEEN '$start_date' AND '$end_date'";
}

if (isset($_GET['payment_status']) && $_GET['payment_status'] !== '') {
    $payment_status = $conn->real_escape_string($_GET['payment_status']);
    $where .= " AND b.payment_status = '$payment_status'";
}

if (isset($_GET['trainer_id']) && $_GET['trainer_id'] !== '') {
    $trainer_id = (int)$_GET['trainer_id'];
    $where .= " AND b.trainer_id = $trainer_id";
}

if (isset($_GET['class_id']) && $_GET['class_id'] !== '') {
    $class_id = (int)$_GET['class_id'];
    $where .= " AND b.class_id = $class_id";
}

// Sorting
if (isset($_GET['sort_by'])) {
    $sort_by = $conn->real_escape_string($_GET['sort_by']);
    $order = isset($_GET['order']) && in_array($_GET['order'], ['ASC', 'DESC']) ? $_GET['order'] : 'ASC';
    $order_by = "$sort_by $order";
}

// Fetch bookings with filters and pagination
$sql_bookings = "SELECT b.*, 
                        u.full_name AS user_name, 
                        t.name AS trainer_name, 
                        c.class_name 
                 FROM bookings b
                 JOIN users u ON b.user_id = u.id
                 JOIN trainers t ON b.trainer_id = t.id
                 JOIN classes c ON b.class_id = c.id
                 WHERE $where
                 ORDER BY $order_by
                 LIMIT $limit OFFSET $offset";
$bookings_result = $conn->query($sql_bookings);
if (!$bookings_result) {
    die("Bookings query failed: " . $conn->error);
}

// Fetch total bookings
$total_bookings_sql = "SELECT COUNT(*) AS total FROM bookings WHERE $where";
$total_bookings_result = $conn->query($total_bookings_sql);
if ($total_bookings_result) {
    $total_bookings_row = $total_bookings_result->fetch_assoc();
    $total_bookings = isset($total_bookings_row['total']) ? $total_bookings_row['total'] : 0;
} else {
    $total_bookings = 0;
}

// Fetch total revenue
$total_revenue_sql = "SELECT SUM(price) AS total FROM bookings WHERE $where";
$total_revenue_result = $conn->query($total_revenue_sql);
if ($total_revenue_result) {
    $total_revenue_row = $total_revenue_result->fetch_assoc();
    $total_revenue = isset($total_revenue_row['total']) ? $total_revenue_row['total'] : 0;
} else {
    $total_revenue = 0;
}

// Fetch trainers & classes for dropdown filters
$trainers = $conn->query("SELECT id, name FROM trainers");
if (!$trainers) {
    die("Trainers query failed: " . $conn->error);
}

$classes = $conn->query("SELECT id, class_name FROM classes");
if (!$classes) {
    die("Classes query failed: " . $conn->error);
}

// Fetch class performance
$sql_class_performance = "SELECT c.class_name, COUNT(b.id) AS bookings, SUM(b.price) AS revenue 
                          FROM classes c 
                          RIGHT JOIN bookings b ON c.id = b.class_id 
                          GROUP BY c.id, c.class_name";
$class_performance_result = $conn->query($sql_class_performance);
if (!$class_performance_result) {
    die("Class performance query failed: " . $conn->error);
}

// Fetch attendance summary for the current year
$sql_attendance_summary = "SELECT MONTH(attendance_date) AS month, COUNT(*) AS present 
                           FROM trainer_attendance 
                           WHERE status = 'Present' AND YEAR(attendance_date) = YEAR(CURRENT_DATE())
                           GROUP BY MONTH(attendance_date)";
$attendance_summary_result = $conn->query($sql_attendance_summary);
if (!$attendance_summary_result) {
    die("Attendance summary query failed: " . $conn->error);
}

// Fetch trainer revenue by month (for the current year)
$sql_trainer_revenue = "SELECT t.name AS trainer_name, 
                               MONTH(b.start_date) AS month, 
                               SUM(b.price) AS total_amount 
                        FROM trainers t 
                        LEFT JOIN bookings b ON t.id = b.trainer_id 
                        WHERE YEAR(b.start_date) = YEAR(CURRENT_DATE()) 
                        GROUP BY t.id, t.name, MONTH(b.start_date)";
$trainer_revenue_result = $conn->query($sql_trainer_revenue);
if (!$trainer_revenue_result) {
    die("Trainer revenue query failed: " . $conn->error);
}

// Process trainer revenue data into a pivot-like structure
$trainer_revenue_data = [];
$months = range(1, 12); // Months 1-12 for the year
while ($row = $trainer_revenue_result->fetch_assoc()) {
    $trainer_name = $row['trainer_name'];
    $month = (int)$row['month'];
    $amount = isset($row['total_amount']) ? $row['total_amount'] : 0;
    if (!isset($trainer_revenue_data[$trainer_name])) {
        $trainer_revenue_data[$trainer_name] = array_fill(1, 12, "NULL"); // Initialize all months to 0
    }
    $trainer_revenue_data[$trainer_name][$month] = $amount;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bookings Report</title>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
        body { background: #f4f4f4; padding: 20px; }
        .container { width: 90%; margin: auto; background: #fff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 20px; }
        .header { background: #007bff; color: #fff; padding: 15px; font-size: 24px; border-radius: 8px 8px 0 0; text-align: center; }
        .filter-box { margin: 20px 0; display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; }
        .filter-box label { margin-right: 5px; font-weight: bold; }
        .filter-box input, .filter-box select { padding: 8px; border: 1px solid #ddd; border-radius: 5px; }
        .btn { padding: 10px 15px; cursor: pointer; border-radius: 5px; border: none; color: #fff; }
        .btn-filter { background: #007bff; }
        .btn-export { background: #17a2b8; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: center; }
        th { background: #007bff; color: #fff; cursor: pointer; }
        th a { color: #fff; text-decoration: none; }
        .summary { margin: 20px 0; font-size: 18px; text-align: center; }
        .chart-container { width: 100%; height: 400px; margin: 20px 0; }
        h2 { color: #007bff; text-align: center; margin: 20px 0; }
    </style>
</head>
<body>

<div class="header">📋 Bookings Report</div>

<div class="container">
    <!-- Filter Form -->
    <form method="GET" class="filter-box">
        <label>📅 Date Range:</label>
        <input type="date" name="start_date" value="<?= isset($_GET['start_date']) ? htmlspecialchars($_GET['start_date']) : ''; ?>">
        <label>to</label>
        <input type="date" name="end_date" value="<?= isset($_GET['end_date']) ? htmlspecialchars($_GET['end_date']) : ''; ?>">

        <label>💳 Payment Status:</label>
        <select name="payment_status">
            <option value="">All</option>
            <option value="Pending" <?= isset($_GET['payment_status']) && $_GET['payment_status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
            <option value="Accepted" <?= isset($_GET['payment_status']) && $_GET['payment_status'] == 'Accepted' ? 'selected' : ''; ?>>Accepted</option>
            <option value="Rejected" <?= isset($_GET['payment_status']) && $_GET['payment_status'] == 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
            <option value="Completed" <?= isset($_GET['payment_status']) && $_GET['payment_status'] == 'Completed' ? 'selected' : ''; ?>>Completed</option>
        </select>

        <label>🏋 Trainer:</label>
        <select name="trainer_id">
            <option value="">All</option>
            <?php while ($row = $trainers->fetch_assoc()): ?>
                <option value="<?= $row['id']; ?>" <?= isset($_GET['trainer_id']) && $_GET['trainer_id'] == $row['id'] ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($row['name']); ?>
                </option>
            <?php endwhile; $trainers->data_seek(0); ?>
        </select>

        <label>🏆 Class:</label>
        <select name="class_id">
            <option value="">All</option>
            <?php while ($row = $classes->fetch_assoc()): ?>
                <option value="<?= $row['id']; ?>" <?= isset($_GET['class_id']) && $_GET['class_id'] == $row['id'] ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($row['class_name']); ?>
                </option>
            <?php endwhile; ?>
        </select>

        <button type="submit" class="btn btn-filter">🔍 Filter</button>
        <button type="button" class="btn btn-export" onclick="window.location.href='export_bookings.php?<?= http_build_query($_GET); ?>'">📥 Export to CSV</button>
    </form>

    <!-- Summary -->
    <div class="summary">
        Total Bookings: <?= $total_bookings; ?> | Total Revenue: ₹<?= number_format($total_revenue, 2); ?>
    </div>

    <!-- Bookings Table -->
    <table>
        <tr>
            <th><a href="?sort_by=b.id&order=ASC">ID ⬆</a> | <a href="?sort_by=b.id&order=DESC">⬇</a></th>
            <th><a href="?sort_by=u.full_name&order=ASC">User ⬆</a> | <a href="?sort_by=u.full_name&order=DESC">⬇</a></th>
            <th><a href="?sort_by=t.name&order=ASC">Trainer ⬆</a> | <a href="?sort_by=t.name&order=DESC">⬇</a></th>
            <th><a href="?sort_by=c.class_name&order=ASC">Class ⬆</a> | <a href="?sort_by=c.class_name&order=DESC">⬇</a></th>
            <th>Package</th>
            <th><a href="?sort_by=b.price&order=ASC">Price ⬆</a> | <a href="?sort_by=b.price&order=DESC">⬇</a></th>
            <th><a href="?sort_by=b.start_date&order=ASC">Start Date ⬆</a> | <a href="?sort_by=b.start_date&order=DESC">⬇</a></th>
            <th>Payment Status</th>
            <th>Payment Proof</th>
            <th>Duration</th>
        </tr>
        <?php while ($row = $bookings_result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['id']); ?></td>
                <td><?= htmlspecialchars($row['user_name']); ?></td>
                <td><?= htmlspecialchars($row['trainer_name']); ?></td>
                <td><?= htmlspecialchars($row['class_name']); ?></td>
                <td><?= htmlspecialchars($row['package_type']); ?></td>
                <td>₹<?= number_format($row['price'], 2); ?></td>
                <td><?= htmlspecialchars($row['start_date']); ?></td>
                <td><?= htmlspecialchars($row['payment_status']); ?></td>
                <td><?= $row['payment_proof'] ? '<a href="uploads/' . htmlspecialchars($row['payment_proof']) . '" target="_blank">View</a>' : 'No Proof'; ?></td>
                <td><?= htmlspecialchars($row['duration']); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <!-- Pagination -->
    <div style="margin: 20px 0; text-align: center;">
        <?php
        $total_pages = ceil($total_bookings / $limit);
        for ($i = 1; $i <= $total_pages; $i++):
            $active = $i == $page ? 'background: #007bff; color: #fff;' : '';
        ?>
            <a href="report_bookings.php?page=<?= $i; ?>&<?= http_build_query($_GET); ?>" class="btn" style="<?= $active; ?>"><?= $i; ?></a>
        <?php endfor; ?>
    </div>

    <!-- Class Performance Table -->
    <h2>Class Performance</h2>
    <table>
        <tr><th>Class Name</th><th>Bookings</th><th>Revenue</th></tr>
        <?php while ($row = $class_performance_result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['class_name']); ?></td>
                <td><?= $row['bookings']; ?></td>
                <td>₹<?= number_format(isset($row['revenue']) ? $row['revenue'] : 0, 2); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <!-- Trainer Revenue by Month Table -->
    <h2>Trainer Revenue by Month (<?= date('Y'); ?>)</h2>
    <table>
        <tr>
            <th>Trainer Name</th>
            <?php foreach ($months as $month): ?>
                <th><?= date('F', mktime(0, 0, 0, $month, 1)); ?></th>
            <?php endforeach; ?>
            <th>Total</th>
        </tr>
        <?php foreach ($trainer_revenue_data as $trainer_name => $monthly_amounts): ?>
            <tr>
                <td><?= htmlspecialchars($trainer_name); ?></td>
                <?php 
                $trainer_total = 0;
                foreach ($months as $month): 
                    $amount = $monthly_amounts[$month];
                    $trainer_total += $amount;
                ?>
                    <td>₹<?= $amount; ?></td>
                <?php endforeach; ?>
                <td>₹<?= $trainer_total; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <!-- Attendance Summary Chart -->
    <h2>Attendance Summary</h2>
    <div class="chart-container" id="attendance_chart"></div>
</div>

<!-- Google Charts Script -->
<script>
google.charts.load('current', {packages: ['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
    var data = google.visualization.arrayToDataTable([
        ['Month', 'Attendance'],
        <?php while ($row = $attendance_summary_result->fetch_assoc()): ?>
            ['<?= date('F', mktime(0, 0, 0, $row['month'], 1)); ?>', <?= $row['present']; ?>],
        <?php endwhile; ?>
    ]);
    var options = { 
        title: 'Monthly Attendance (This Year)', 
        curveType: 'function', 
        legend: { position: 'bottom' },
        vAxis: { minValue: 0 }
    };
    var chart = new google.visualization.LineChart(document.getElementById('attendance_chart'));
    chart.draw(data, options);
}
</script>

</body>
</html>