<?php
// Start session to access session variables
session_start();

// Database connection
$servername = "localhost";
$username = "root"; // Adjust according to your database credentials
$password = ""; // Adjust according to your database credentials
$dbname = "fitness_booking";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetching classes data
$sql = "SELECT id, class_name, description FROM classes";
$result = $conn->query($sql);

// Function to generate a random color
function generateRandomColor() {
    // Generate a random color in hex format
    $color = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
    return $color;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym Home - Fitness Class</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Basic Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f8ff;
            color: #333;
        }

        nav {
            background-color: #2d87f0;
            padding: 10px 20px;
            text-align: center;
        }

        nav a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
            font-size: 1.2rem;
        }

        nav a:hover {
            text-decoration: underline;
            color: #ff6347;
        }

        /* Hero Section */
        .hero {
            background-color: #ff6347;
            color: white;
            text-align: center;
            padding: 50px 0;
        }

        .hero h1 {
            font-size: 3.5rem;
            margin-bottom: 20px;
        }

        .hero p {
            font-size: 1.5rem;
            margin-bottom: 30px;
        }

        .btn {
            background-color: #fff;
            color: #ff6347;
            padding: 12px 30px;
            font-size: 1.2rem;
            text-decoration: none;
            border-radius: 5px;
            border: 2px solid #ff6347;
        }

        .btn:hover {
            background-color: #ff4500;
            color: white;
        }

        /* Classes Section */
        .classes {
            padding: 70px 20px;
            text-align: center;
            background-color: #ffffff;
            display: flex;
            justify-content: space-between;
            gap: 30px;
            flex-wrap: wrap;
        }

        .classes h2 {
            font-size: 2.8rem;
            margin-bottom: 40px;
            color: #333;
            text-transform: uppercase;
            font-weight: bold;
            width: 100%;
            text-align: center;
        }

        /* Class Card Styles */
        .class-card {
            padding: 12px;
            margin: 10px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            text-align: left;
            width: 28%;
            min-height: 220px;
            box-sizing: border-box;
            color: #fff;
            background-color: #2d87f0;
        }

        .class-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        .class-card h3 {
            font-size: 1.8rem;
            font-weight: bold;
            color: #ff6347; /* Highlighted class name with a vibrant color */
            text-transform: uppercase;
            margin-bottom: 15px;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); /* Adding shadow for emphasis */
        }

        .class-card p {
            font-size: 1rem;
            margin-bottom: 15px;
            line-height: 1.6;
        }

        .class-card button {
            background-color: #fff;
            color: #333;
            padding: 8px 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .class-card button:hover {
            background-color: #333;
            color: #fff;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .class-card {
                width: 45%;
            }
        }

        @media (max-width: 768px) {
            .class-card {
                width: 100%;
                max-width: 400px;
                margin: 10px auto;
            }
        }

        /* Footer Styles */
        footer {
            text-align: center;
            background-color: #333;
            color: white;
            padding: 20px;
            margin-top: 40px;
        }

        footer p {
            margin: 0;
            font-size: 1rem;
        }

        /* User Profile Modal */
        #profileModal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .profile-content {
            background: white;
            padding: 30px;
            border-radius: 8px;
            width: 400px;
            text-align: center;
        }

        .profile-content h3 {
            font-size: 2rem;
            margin-bottom: 20px;
        }

        .profile-content p {
            font-size: 1.2rem;
            margin-bottom: 20px;
        }

        .profile-content button {
            background-color: #ff6347;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 1rem;
            border-radius: 5px;
            cursor: pointer;
        }

        .profile-content button:hover {
            background-color: #ff4500;
        }

        .profile-btn {
            background-color: #2d87f0;
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: inline-block;
            text-align: center;
            line-height: 40px;
            font-size: 1.2rem;
            font-weight: bold;
            cursor: pointer;
        }

        .profile-btn:hover {
            background-color: #ff6347;
        }
/* Notification Badge */
.notif-badge {
    background-color: red;
    color: white;
    font-size: 14px;
    font-weight: bold;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    display: inline-block;
    text-align: center;
    line-height: 20px;
    position: absolute;
    top: 5px;
    right: 5px;
}
.profile-btn {
    background-color: #2d87f0;
    color: white;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: inline-block;
    text-align: center;
    line-height: 40px;
    font-size: 1.2rem;
    font-weight: bold;
    cursor: pointer;
    position: relative; /* Added for correct notification badge positioning */
}

.profile-btn:hover {
    background-color: #ff6347;
}

/* Notification Badge */
.notif-badge {
    background-color: red;
    color: white;
    font-size: 12px;
    font-weight: bold;
    width: 18px;
    height: 18px;
    border-radius: 50%;
    display: inline-block;
    text-align: center;
    line-height: 18px;
    position: absolute;
    top: 0px; /* Adjusted to place closer to the button */
    right: 0px; /* Adjusted to align properly */
    transform: translate(50%, -50%);
    box-shadow: 0 0 4px rgba(0, 0, 0, 0.3);
}



    </style>
</head>

<body>
    <!-- Navigation -->
    <nav>
        <a href="./about_us.php">About Us</a>
        <a href="./services.php">Services</a>
        <a href="#classes">View Classes</a>
        <a href="./contact.php">Contact Us</a>
        <a href="./trainer_login.php">Trainer</a>
        <a href="admin_login.php">Admin</a>
        <?php
// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id']; // Get logged-in user ID

    // Fetch the count of unread notifications
    $notifQuery = "SELECT COUNT(*) AS unread_count FROM notifications WHERE user_id = ? AND status = 'unread'";
    $stmt = $conn->prepare($notifQuery);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $notifResult = $stmt->get_result();
    $notifRow = $notifResult->fetch_assoc();
    $unreadCount = $notifRow['unread_count']; // Get the unread notification count

    // Get the first initial of the username
    $firstInitial = strtoupper(substr($_SESSION['username'], 0, 1));

    // Display profile button with notification count
    echo '<a href="profile.php"><div class="profile-btn">';
    echo $firstInitial;

    // Display unread notifications count if there are new messages
    if ($unreadCount > 0) {
        echo '<span class="notif-badge">' . $unreadCount . '</span>';
    }

    echo '</div></a>';
}
?>


    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div>
            <h1>Welcome to Fitness Hub</h1>
            <p>Your Journey to a Healthier You Begins Here</p>
            <a href="#services" class="btn">Explore Our Services</a>
        </div>
    </section>

    <!-- Classes Section -->
    <section id="classes" class="classes">
        <h2>View Our Classes</h2>

        <?php
        if ($result->num_rows > 0) {
            $count = 1;
            while ($row = $result->fetch_assoc()) {
                // Generate random color for each card
                $randomColor = generateRandomColor();
                echo '<div class="class-card" style="background-color:' . $randomColor . ';">
                        <h3>' . htmlspecialchars($row['class_name']) . '</h3>
                        <p>' . htmlspecialchars($row['description']) . '</p>
                        <a href="trainer_details.php?class_id=' . htmlspecialchars($row['id']) . '">
                            <button>Choose Trainer</button>
                        </a>
                      </div>';
                $count++;
            }
        } else {
            echo "<p>No classes available at the moment.</p>";
        }

        $conn->close();
        ?>
    </section>

    <!-- User Profile Modal -->
    <div id="profileModal">
        <div class="profile-content">
            <h3>User Profile</h3>
            <p>Username: <?php echo htmlspecialchars($_SESSION['username']); ?></p>
            <p>Email: <?php echo htmlspecialchars($_SESSION['email']); ?></p>
            <button onclick="closeProfile()">Close</button>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Fitness Hub. All Rights Reserved.</p>
    </footer>

    <script>
    function fetchNotifications() {
        fetch("fetch_notifications.php") // Calls a PHP file to get the count
            .then(response => response.text())
            .then(data => {
                let badge = document.querySelector('.notif-badge');
                if (data > 0) {
                    if (!badge) {
                        let profileBtn = document.querySelector('.profile-btn');
                        let newBadge = document.createElement('span');
                        newBadge.className = 'notif-badge';
                        newBadge.innerText = data;
                        profileBtn.appendChild(newBadge);
                    } else {
                        badge.innerText = data;
                    }
                } else {
                    if (badge) badge.remove();
                }
            });
    }

    setInterval(fetchNotifications, 15000); // Refresh every 5 seconds
</script>

</body>

</html>
