<?php
session_start();
include 'db.php';

// Ensure trainer is logged in
if (!isset($_SESSION['trainer_logged_in']) || $_SESSION['trainer_logged_in'] !== true) {
    header("Location: trainer_login.php");
    exit();
}

$trainer_id = $_SESSION['trainer_id'];
$current_date = date('Y-m-d');

// Fetch unique attendees for the trainer's class with latest remaining_days value, excluding remaining_days = 0
$sql = "SELECT u.id, u.full_name, u.username, u.email, u.phone, 
               c.class_name, b.duration_text, 
               MAX(ta.added_at) AS latest_added_at,
               (SELECT ta3.remaining_days 
                FROM trainer_attendance ta3 
                WHERE ta3.student_id = ta.student_id 
                AND ta3.trainer_id = ? 
                ORDER BY ta3.added_at DESC LIMIT 1) AS remaining_days,
               (SELECT MAX(attendance_date) FROM trainer_attendance ta2 
                WHERE ta2.student_id = ta.student_id AND ta2.trainer_id = ?) AS last_attendance_date
        FROM trainer_attendance AS ta
        JOIN users AS u ON ta.student_id = u.id
        JOIN bookings AS b ON ta.student_id = b.user_id
        JOIN classes AS c ON b.class_id = c.id
        WHERE ta.trainer_id = ? 
          AND b.trainer_id = ?
          AND (SELECT ta3.remaining_days FROM trainer_attendance ta3 WHERE ta3.student_id = ta.student_id 
               AND ta3.trainer_id = ? ORDER BY ta3.added_at DESC LIMIT 1) > 0
        GROUP BY u.id, u.full_name, u.username, u.email, u.phone, c.class_name, b.duration_text
        ORDER BY latest_added_at DESC";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}

$stmt->bind_param("iiiii", $trainer_id, $trainer_id, $trainer_id, $trainer_id, $trainer_id);
$stmt->execute();
$result = $stmt->get_result();

$attendees = [];
while ($row = $result->fetch_assoc()) {
    $row['attendance_today'] = ($row['last_attendance_date'] === $current_date) ? true : false;
    $attendees[] = $row;
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trainer Attendance</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f8f9fa; padding: 20px; }
        h2 { text-align: center; color: #007bff; }
        table { width: 90%; margin: auto; border-collapse: collapse; background-color: white; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        th, td { padding: 10px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #007bff; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .btn-present, .btn-absent { padding: 5px 10px; border: none; border-radius: 3px; cursor: pointer; color: white; }
        .btn-present { background-color: #28a745; }
        .btn-present:hover { background-color: #218838; }
        .btn-absent { background-color: #dc3545; }
        .btn-absent:hover { background-color: #c82333; }
        .disabled { background-color: gray; cursor: not-allowed; }
    </style>
</head>
<body>

<h2>Trainer Attendees List</h2>

<?php if (empty($attendees)): ?>
    <p style="text-align: center; color: red;">No students added to attendance sheet yet.</p>
<?php else: ?>
    <table id="attendance-table">
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Username</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Class</th>
            <th>Duration</th>
            <th>Remaining Days</th>
            <th>Added On</th>
            <th>Mark Attendance</th>
        </tr>
        <?php foreach ($attendees as $attendee): ?>
            <tr id="row-<?= $attendee['id']; ?>">
                <td><?= htmlspecialchars($attendee['id']); ?></td>
                <td><?= htmlspecialchars($attendee['full_name']); ?></td>
                <td><?= htmlspecialchars($attendee['username']); ?></td>
                <td><?= htmlspecialchars($attendee['email']); ?></td>
                <td><?= htmlspecialchars($attendee['phone']); ?></td>
                <td><?= htmlspecialchars($attendee['class_name']); ?></td>
                <td><?= htmlspecialchars(isset($attendee['duration_text']) ? $attendee['duration_text'] : 'Not Available'); ?></td>
                <td class="remaining-days"><?= htmlspecialchars($attendee['remaining_days']); ?></td>
                <td><?= htmlspecialchars($attendee['latest_added_at']); ?></td>
                <td>
                    <button class="btn-present <?= $attendee['attendance_today'] ? 'disabled' : ''; ?>"
                            onclick="markAttendance(<?= $attendee['id']; ?>, 'Present')"
                            <?= $attendee['attendance_today'] ? 'disabled' : ''; ?>>Present</button>
                    <button class="btn-absent <?= $attendee['attendance_today'] ? 'disabled' : ''; ?>"
                            onclick="markAttendance(<?= $attendee['id']; ?>, 'Absent')"
                            <?= $attendee['attendance_today'] ? 'disabled' : ''; ?>>Absent</button>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>

<script>
function markAttendance(studentId, status) {
    fetch('update_attendance.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `student_id=${studentId}&status=${status}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Attendance updated!");

            let row = document.getElementById(`row-${studentId}`);
            if (!row) return;

            let remainingDaysElement = row.querySelector(".remaining-days");
            if (remainingDaysElement) {
                let remainingDays = parseInt(remainingDaysElement.textContent);
                remainingDays--;

                if (remainingDays <= 0) {
                    row.remove();  // Remove row from table
                } else {
                    remainingDaysElement.textContent = remainingDays;
                }
            }
        } else {
            alert(data.message || "Error updating attendance!");
        }
    })
    .catch(error => console.error("Error:", error));
}
</script>

</body>
</html>
