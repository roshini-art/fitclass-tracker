<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fitness_booking";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Verify connection is still active
if (!$conn->ping()) {
    die("Database connection lost: " . $conn->error);
}

// Fetch user ID and last login
$user = $_SESSION['username'];
$sql = "SELECT id, last_login FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Prepare failed for user query: " . $conn->error);
}
$stmt->bind_param("s", $user);
$stmt->execute();
$result = $stmt->get_result();
$userData = $result->fetch_assoc();

if (!$userData) {
    echo "User not found.";
    exit();
}

$user_id = $userData['id'];
$last_login = $userData['last_login'];
$stmt->close();

// Update last activity time
$update_activity = "UPDATE users SET last_activity = NOW() WHERE id = ?";
$stmt_activity = $conn->prepare($update_activity);
if ($stmt_activity === false) {
    die("Prepare failed for activity update: " . $conn->error);
}
$stmt_activity->bind_param("i", $user_id);
$stmt_activity->execute();
$stmt_activity->close();

// Fetch trainer's feedback from notifications
$notification_sql = "SELECT message, created_at FROM notifications WHERE user_id = ? AND status = 'unread' ORDER BY created_at DESC LIMIT 1";
$notification_stmt = $conn->prepare($notification_sql);
if ($notification_stmt === false) {
    die("Prepare failed for notification query: " . $conn->error . " | SQL attempted: " . $notification_sql);
}
$notification_stmt->bind_param("i", $user_id);
if (!$notification_stmt->execute()) {
    die("Execute failed for notification query: " . $notification_stmt->error);
}
$notifications_result = $notification_stmt->get_result();

// Mark notifications as read
$update_notifications = "UPDATE notifications SET status = 'read' WHERE user_id = ? AND status = 'unread'";
$update_stmt = $conn->prepare($update_notifications);
if ($update_stmt === false) {
    die("Prepare failed for update notifications: " . $conn->error);
}
$update_stmt->bind_param("i", $user_id);
$update_stmt->execute();
$update_stmt->close();

// Fetch last fitness update date
$sql_last_update = "SELECT created_at FROM fitness_tracking WHERE user_id = ? ORDER BY created_at DESC LIMIT 1";
$stmt_last_update = $conn->prepare($sql_last_update);
if ($stmt_last_update === false) {
    die("Prepare failed for last update query: " . $conn->error);
}
$stmt_last_update->bind_param("i", $user_id);
$stmt_last_update->execute();
$result_last_update = $stmt_last_update->get_result();
$last_update_row = $result_last_update->fetch_assoc();
$last_update = $last_update_row ? $last_update_row['created_at'] : "No record";
$stmt_last_update->close();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $height = $_POST['height'];
    $weight = $_POST['weight'];
    $extra_notes = $_POST['extra_notes'];

    // Validate input
    if (!is_numeric($height) || !is_numeric($weight) || $height <= 0 || $weight <= 0) {
        echo "<script>alert('Invalid input. Please enter valid numbers.');</script>";
    } else {
        // Convert height to meters and calculate BMI
        $height_m = $height / 100;
        $bmi = round($weight / ($height_m * $height_m), 2);

        // Determine BMI category
        if ($bmi < 18.5) {
            $bmi_category = "Underweight";
        } elseif ($bmi >= 18.5 && $bmi <= 24.9) {
            $bmi_category = "Normal";
        } elseif ($bmi >= 25 && $bmi <= 29.9) {
            $bmi_category = "Overweight";
        } else {
            $bmi_category = "Obese";
        }

        // Prevent duplicate entries for the same day
        $check_sql = "SELECT id FROM fitness_tracking WHERE user_id = ? AND DATE(created_at) = CURDATE()";
        $stmt_check = $conn->prepare($check_sql);
        if ($stmt_check === false) {
            die("Prepare failed for check query: " . $conn->error);
        }
        $stmt_check->bind_param("i", $user_id);
        $stmt_check->execute();
        $stmt_check->store_result();

        if ($stmt_check->num_rows > 0) {
            echo "<script>alert('You have already recorded fitness data for today.');</script>";
        } else {
            // Insert new fitness entry
            $sql_insert = "INSERT INTO fitness_tracking (user_id, height, weight, bmi, bmi_category, extra_notes, created_at) 
                           VALUES (?, ?, ?, ?, ?, ?, NOW())";
            $stmt_insert = $conn->prepare($sql_insert);
            if ($stmt_insert === false) {
                die("Prepare failed for insert query: " . $conn->error);
            }
            $stmt_insert->bind_param("iddsss", $user_id, $height, $weight, $bmi, $bmi_category, $extra_notes);

            if ($stmt_insert->execute()) {
                echo "<script>alert('Fitness data recorded successfully!'); window.location.href='fitness_tracking.php';</script>";
            } else {
                echo "Error: " . $stmt_insert->error;
            }
            $stmt_insert->close();
        }
        $stmt_check->close();
    }
}

// Fetch user's fitness tracking data
$sql_tracking = "SELECT * FROM fitness_tracking WHERE user_id = ? ORDER BY created_at DESC";
$stmt_tracking = $conn->prepare($sql_tracking);
if ($stmt_tracking === false) {
    die("Prepare failed for tracking query: " . $conn->error);
}
$stmt_tracking->bind_param("i", $user_id);
$stmt_tracking->execute();
$result_tracking = $stmt_tracking->get_result();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fitness Tracking</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #f4f4f9;
            color: #333;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h2, h3 {
            color: #007bff;
            text-align: center;
            margin-bottom: 20px;
        }

        p {
            margin: 10px 0;
            font-size: 16px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-weight: bold;
            color: #333;
        }

        input[type="number"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }

        input[type="number"]:focus,
        textarea:focus {
            border-color: #007bff;
            outline: none;
        }

        textarea {
            height: 100px;
            resize: vertical;
        }

        button.btn, a.btn {
            display: inline-block;
            padding: 10px 15px;
            background: #007bff;
            color: #fff;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button.btn:hover, a.btn:hover {
            background: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        th {
            background: #007bff;
            color: #fff;
        }

        .notifications {
            margin-top: 20px;
            padding: 15px;
            background: #f9f9f9;
            border-radius: 5px;
            border: 1px solid #ddd;
        }

        .notification-item {
            padding: 10px;
            border-bottom: 1px solid #eee;
        }

        .notification-item:last-child {
            border-bottom: none;
        }

        .notification-item p {
            margin: 0;
            font-size: 14px;
        }

        .notification-item small {
            color: #666;
            font-size: 12px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Fitness Tracking</h2>

        <?php if ($notifications_result->num_rows > 0): ?>
            <div class="notifications">
                <h3>Trainer's Latest Feedback</h3>
                <?php while ($notification = $notifications_result->fetch_assoc()): ?>
                    <div class="notification-item">
                        <p><?= htmlspecialchars($notification['message']); ?></p>
                        <small>Received: <?= htmlspecialchars($notification['created_at']); ?></small>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>

        <p><strong>Last Fitness Update:</strong> <?= htmlspecialchars($last_update); ?></p>

        <form method="POST">
            <label>Height (cm):</label>
            <input type="number" name="height" required>

            <label>Weight (kg):</label>
            <input type="number" step="0.1" name="weight" required>

            <label>Extra Notes (Workout details, diet, etc.):</label>
            <textarea name="extra_notes"></textarea>

            <button type="submit" class="btn">Save Fitness Data</button>
        </form>

        <h3>Your Fitness Records</h3>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Height (cm)</th>
                    <th>Weight (kg)</th>
                    <th>BMI</th>
                    <th>Category</th>
                    <th>Notes</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result_tracking->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['created_at']); ?></td>
                        <td><?= htmlspecialchars($row['height']); ?></td>
                        <td><?= htmlspecialchars($row['weight']); ?></td>
                        <td><?= isset($row['bmi']) ? htmlspecialchars($row['bmi']) : 'N/A'; ?></td>
                        <td><?= isset($row['bmi_category']) ? htmlspecialchars($row['bmi_category']) : 'N/A'; ?></td>
                        <td><?= htmlspecialchars($row['extra_notes']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <a href="profile.php" class="btn">Back to Profile</a>
    </div>
</body>
</html>

<?php
// Close the notification statement
$notification_stmt->close();
?>