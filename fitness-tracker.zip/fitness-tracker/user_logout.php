<?php
session_start();

// Unset all session variables
session_unset();

// Destroy the session
session_destroy();

// Set a session message to indicate successful logout
session_start();
$_SESSION['logout_message'] = "Logout successful! You will be redirected shortly.";

// Redirect to the index page
header("Location: index.php");
exit();
?>
