<?php
session_start();
include('db.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
    $sql = "INSERT INTO users (username, password, role) VALUES ('$username', '$password', 'trainer')";
    
    if ($conn->query($sql) === TRUE) {
        echo "New trainer added successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!-- HTML for adding a trainer -->
<form action="add_trainer.php" method="POST">
    <label for="username">Username:</label>
    <input type="text" name="username" required><br>
    <label for="password">Password:</label>
    <input type="password" name="password" required><br>
    <input type="submit" value="Add Trainer">
</form>
