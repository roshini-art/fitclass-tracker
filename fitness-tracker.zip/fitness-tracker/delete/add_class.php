<?php
session_start();
include('db.php'); // Ensure db.php contains $conn for database connection

// Redirect to login if admin is not logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit;
}

// Initialize a message variable
$message = "";

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize inputs to prevent SQL injection
    $class_name = $conn->real_escape_string($_POST['class_name']);
    $timing = $conn->real_escape_string($_POST['timing']);
    $trainer_id = (int) $_POST['trainer_id'];

    // Insert into the database
    $sql = "INSERT INTO classes (name, timing, trainer_id) VALUES ('$class_name', '$timing', $trainer_id)";

    if ($conn->query($sql) === TRUE) {
        $message = "<p style='color: green;'>New class added successfully!</p>";
    } else {
        $message = "<p style='color: red;'>Error: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Class</title>
</head>
<body>
    <h2>Add New Class</h2>
    <form action="add_class.php" method="POST">
        <label for="class_name">Class Name:</label>
        <input type="text" name="class_name" required><br>

        <label for="timing">Timing:</label>
        <input type="time" name="timing" required><br>

        <label for="trainer_id">Trainer ID:</label>
        <select name="trainer_id" required>
            <?php
            // Fetch trainers to populate the dropdown
            $trainer_query = "SELECT id, name FROM trainers";
            $result = $conn->query($trainer_query);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                }
            } else {
                echo "<option value='' disabled>No trainers available</option>";
            }
            ?>
        </select><br>

        <input type="submit" value="Add Class">
    </form>

    <!-- Display success or error message under the form -->
    <?= $message; ?>
</body>
</html>
