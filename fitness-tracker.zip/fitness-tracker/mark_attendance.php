<?php
session_start();
include 'db.php';

if (!isset($_SESSION['trainer_logged_in']) || $_SESSION['trainer_logged_in'] !== true) {
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['student_id']) && isset($_POST['status'])) {
    $trainer_id = $_SESSION['trainer_id'];
    $student_id = $_POST['student_id'];
    $status = $_POST['status'];
    $date = date('Y-m-d');

    // Insert attendance record
    $sql = "INSERT INTO trainer_attendance (trainer_id, student_id, attendance_date, status) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiss", $trainer_id, $student_id, $date, $status);

    if ($stmt->execute()) {
        // Decrement remaining days
        $updateSql = "UPDATE trainer_attendance SET remaining_days = remaining_days - 1 WHERE trainer_id = ? AND student_id = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param("ii", $trainer_id, $student_id);
        $updateStmt->execute();
        $updateStmt->close();

        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => "Database error"]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false, "message" => "Invalid request"]);
}
