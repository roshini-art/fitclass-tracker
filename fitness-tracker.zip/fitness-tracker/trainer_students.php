<?php
session_start();
include 'db.php';

// Check if trainer is logged in
if (!isset($_SESSION['trainer_logged_in']) || $_SESSION['trainer_logged_in'] !== true) {
    header("Location: trainer_login.php");
    exit();
}

$trainer_id = $_SESSION['trainer_id'];

// Fetch assigned students and check if they have received messages
$sql = "SELECT u.id, u.full_name, u.username, u.email, u.phone, c.class_name, 
               b.package_type, b.start_date, b.duration_text, b.created_at,
               (SELECT COUNT(*) FROM notifications WHERE user_id = u.id) AS message_count
        FROM bookings AS b
        JOIN users AS u ON b.user_id = u.id
        JOIN classes AS c ON b.class_id = c.id
        WHERE b.trainer_id = ? AND b.payment_status = 'Accepted'
        ORDER BY b.created_at DESC";


$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $trainer_id);
$stmt->execute();
$result = $stmt->get_result();

$students = [];
while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}
$stmt->close();

// Handle message sending
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['send_message'])) {
    $student_id = $_POST['student_id'];
    $message = trim($_POST['message']);

    if (!empty($message)) {
        $sql = "INSERT INTO notifications (user_id, message, status, created_at) VALUES (?, ?, 'unread', NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $student_id, $message);
        if ($stmt->execute()) {
            echo "<script>window.location.href='trainer_students.php';</script>";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assigned Students</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f8f9fa; margin: 0; padding: 20px; }
        h2 { text-align: center; color: #007bff; }
        table { width: 80%; margin: 20px auto; border-collapse: collapse; background-color: white; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        th, td { padding: 10px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #007bff; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .highlight { background-color: yellow !important; } /* New User Highlight */
        .message-form { text-align: center; margin-top: 10px; }
        .message-form textarea { width: 80%; padding: 10px; margin-bottom: 10px; }
        .message-form button { padding: 10px 20px; background-color: #007bff; color: white; border: none; cursor: pointer; }
        .message-form button:hover { background-color: #0056b3; }
        .view-msg-btn { padding: 5px 10px; background-color: #28a745; color: white; border: none; cursor: pointer; margin-top: 5px; }
        .view-msg-btn:hover { background-color: #218838; }
        .messages-box { display: none; padding: 10px; background: #f1f1f1; border: 1px solid #ccc; margin-top: 10px; max-height: 200px; overflow-y: auto; }
        .close-btn { float: right; background: red; color: white; border: none; padding: 2px 5px; cursor: pointer; }
    </style>
</head>
<script>
function validateAttendance(studentId) {
    var inputField = document.getElementById("attendance_days_" + studentId);
    var enteredDays = parseInt(inputField.value, 10);
    var durationDays = parseInt(inputField.getAttribute("data-duration"), 10);
    var errorMsg = document.getElementById("error_message_" + studentId);

    if (enteredDays !== durationDays) {
        errorMsg.style.display = "block"; // Show error message
        return false; // Prevent form submission
    }

    errorMsg.style.display = "none"; // Hide error if valid
    return true;
}
</script>


<body>

<h2>Assigned Students</h2>

<?php if (empty($students)): ?>
    <p style="text-align: center; color: red;">No students assigned yet.</p>
<?php else: ?>
    <table>
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Username</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Class</th>
            <th>Package</th>
            <th>Start Date</th>
            <th>Duration</th> <!-- New Column Added -->
            <th>Actions</th>
        </tr>
        <?php foreach ($students as $student): ?>
            <tr class="<?= $student['message_count'] == 0 ? 'highlight' : ''; ?>" id="row-<?= $student['id']; ?>">
                <td><?= htmlspecialchars($student['id']); ?></td>
                <td><?= htmlspecialchars($student['full_name']); ?></td>
                <td><?= htmlspecialchars($student['username']); ?></td>
                <td><?= htmlspecialchars($student['email']); ?></td>
                <td><?= htmlspecialchars($student['phone']); ?></td>
                <td><?= htmlspecialchars($student['class_name']); ?></td>
                <td><?= htmlspecialchars($student['package_type']); ?></td>
                <td><?= htmlspecialchars($student['start_date']); ?></td> 
                <td><?= isset($student['duration_text']) ? htmlspecialchars($student['duration_text']. ' DAYS') : 'Not Available'; ?></td>
<!-- Displaying Start Date -->
                <td>
    <!-- Message Form -->
    <form method="POST" class="message-form" onsubmit="removeHighlight(<?= $student['id']; ?>)">
        <input type="hidden" name="student_id" value="<?= $student['id']; ?>">
        <textarea name="message" placeholder="Type your message..."></textarea><br>
        <button type="submit" name="send_message">Send</button>
    </form>

    <!-- View Messages Button -->
    <button class="view-msg-btn" onclick="viewMessages(<?= $student['id']; ?>)">View Messages</button>

    <!-- Messages Box -->
    <div class="messages-box" id="messages-<?= $student['id']; ?>">
        <button class="close-btn" onclick="closeMessages(<?= $student['id']; ?>)">×</button>
        <h4>Messages:</h4>
        <ul id="message-list-<?= $student['id']; ?>"></ul>
    </div>

    <!-- Add to Attendees Button -->
<form method="POST" action="attendance.php" onsubmit="return validateAttendance(<?= $student['id']; ?>)">
    <input type="hidden" name="student_id" value="<?= htmlspecialchars($student['id']); ?>">
    
    <!-- Store duration as a data attribute -->
    <input type="number" name="attendance_days" id="attendance_days_<?= $student['id']; ?>"
           placeholder="Enter Days" required data-duration="<?= htmlspecialchars($student['duration_text']); ?>">
    
    <button type="submit" name="set_attendance">Add to Attendees Sheet</button>
    <p id="error_message_<?= $student['id']; ?>" style="color: red; display: none;">Entered days must match the duration days!</p>
</form>


</td>

            </tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>

<!-- JavaScript to Fetch Messages & Remove Highlight -->
<script>
    function viewMessages(studentId) {
        var msgBox = document.getElementById("messages-" + studentId);
        var msgList = document.getElementById("message-list-" + studentId);

        if (msgBox.style.display === "block") {
            msgBox.style.display = "none";
            return;
        }

        msgList.innerHTML = "<li>Loading...</li>";

        fetch("fetch_messages.php?student_id=" + studentId)
            .then(response => response.json())
            .then(data => {
                msgList.innerHTML = "";
                if (data.length === 0) {
                    msgList.innerHTML = "<li>No messages found.</li>";
                } else {
                    data.forEach(msg => {
                        var listItem = document.createElement("li");
                        listItem.textContent = msg.message + " (" + msg.created_at + ")";
                        msgList.appendChild(listItem);
                    });
                }
            })
            .catch(error => {
                msgList.innerHTML = "<li>Error loading messages.</li>";
                console.error("Error fetching messages:", error);
            });

        msgBox.style.display = "block";
    }

    function closeMessages(studentId) {
        document.getElementById("messages-" + studentId).style.display = "none";
    }

    function removeHighlight(studentId) {
        document.getElementById("row-" + studentId).classList.remove("highlight");
    }
</script>

</body>
</html>
