<?php
session_start();
include 'db.php'; // Include database connection file

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "Please log in to view your attendance.";
    exit;
}

$user_id = $_SESSION['user_id']; // Get logged-in user's ID

// Fetch attendance details for the user
$sql = "SELECT ta.attendance_date, ta.status, ta.remaining_days, 
               t.name AS trainer_name
        FROM trainer_attendance ta
        JOIN trainers t ON ta.trainer_id = t.id
        WHERE ta.student_id = ? 
        ORDER BY ta.attendance_date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Attendance</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file -->
    <style>
        /* Styling for the table */
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid black;
        }
        th {
            background-color: #3b92d9;
        }
        .absent {
            background-color: #ffcccc; /* Light red for absent rows */
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h2>My Attendance Details</h2>

    <table>
        <tr>
            <th>Date</th>
            <th>Status</th>
            <th>Remaining Days</th>
            <th>Trainer Name</th>
        </tr>

        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $row_class = ($row['status'] == 'Absent') ? 'class="absent"' : '';
                echo "<tr $row_class>";
                echo "<td>" . $row['attendance_date'] . "</td>";
                echo "<td>" . $row['status'] . "</td>";
                echo "<td>" . $row['remaining_days'] . "</td>";
                echo "<td>" . $row['trainer_name'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No attendance records found.</td></tr>";
        }
        ?>
    </table>

    <a href="dashboard.php">Back to Dashboard</a> <!-- Back button -->
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
