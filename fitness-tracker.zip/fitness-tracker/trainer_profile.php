<?php
session_start();
if (!isset($_SESSION['trainer_logged_in']) || $_SESSION['trainer_logged_in'] !== true) {
    header("Location: trainer_login.php");
    exit();
}

// Include the database connection
include 'db.php';

// Get the trainer ID from the session or query string
$trainer_id = $_SESSION['trainer_id'];

// Fetch the trainer details from the database
$sql = "SELECT * FROM trainers WHERE id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $trainer_id);
    $stmt->execute();
    $trainer = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Handle Profile Update
if (isset($_POST['update_profile'])) {
    $trainer_name = $_POST['trainer_name'];
    $specialization = $_POST['specialization'];
    $contact_number = $_POST['contact_number'];
    $email = $_POST['email'];
    $trainer_image = $_FILES['trainer_image']['name'];

    if (!empty($trainer_image)) {
        $target_dir = "uploads/"; 
        $target_file = $target_dir . basename($trainer_image);
        move_uploaded_file($_FILES['trainer_image']['tmp_name'], $target_file);
    } else {
        $trainer_image = $trainer['image']; // Keep the existing image if none is uploaded
    }

    // Update the trainer details in the database
    $sql = "UPDATE trainers SET name = ?, specialization = ?, contact_number = ?, email = ?, image = ? WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("sssssi", $trainer_name, $specialization, $contact_number, $email, $trainer_image, $trainer_id);

        if ($stmt->execute()) {
            $success_message = "Profile updated successfully!";
        } else {
            $error_message = "Error updating profile: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $error_message = "Error preparing statement: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trainer Profile</title>
    <style>
        /* Include your CSS styling for the profile page here */
    </style>
</head>
<body>
    <h1>Trainer Profile</h1>

    <?php if ($success_message) { ?>
        <div class="message success-message"><?php echo $success_message; ?></div>
    <?php } ?>
    <?php if ($error_message) { ?>
        <div class="message error-message"><?php echo $error_message; ?></div>
    <?php } ?>

    <form method="POST" enctype="multipart/form-data">
        <label for="trainer_name">Trainer Name:</label>
        <input type="text" name="trainer_name" id="trainer_name" value="<?php echo $trainer['name']; ?>" required>

        <label for="specialization">Specialization:</label>
        <input type="text" name="specialization" id="specialization" value="<?php echo $trainer['specialization']; ?>" required>

        <label for="contact_number">Contact Number:</label>
        <input type="tel" name="contact_number" id="contact_number" value="<?php echo $trainer['contact_number']; ?>" required>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" value="<?php echo $trainer['email']; ?>" required>

        <label for="trainer_image">Profile Image:</label>
        <input type="file" name="trainer_image" id="trainer_image">

        <img src="uploads/<?php echo $trainer['image']; ?>" alt="Trainer Image" style="max-width: 150px; margin-top: 10px;">

        <input type="submit" name="update_profile" value="Update Profile">
    </form>
</body>
</html>
