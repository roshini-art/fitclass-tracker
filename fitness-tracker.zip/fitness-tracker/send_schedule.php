<?php
session_start();
include 'db.php';

// Ensure the trainer is logged in
if (!isset($_SESSION['trainer_logged_in']) || $_SESSION['trainer_logged_in'] !== true || !isset($_SESSION['trainer_id'])) {
    header("Location: trainer_login.php");
    exit();
}

$trainer_id = $_SESSION['trainer_id'];
$message = "";

// Fetch all classes for the trainer
$class_query = "SELECT id, class_name FROM classes";
$class_result = $conn->query($class_query);

if (!$class_result) {
    die("Error fetching classes: " . $conn->error);
}

$classes = $class_result->fetch_all(MYSQLI_ASSOC);

// Fetch only users who have booked and paid for a class with this trainer
$user_query = "SELECT DISTINCT u.id, u.full_name 
               FROM bookings b
               JOIN users u ON b.user_id = u.id
               WHERE b.trainer_id = ? AND b.payment_status = 'Accepted'";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $trainer_id);
$stmt->execute();
$user_result = $stmt->get_result();

if (!$user_result) {
    die("Error fetching users: " . $conn->error);
}

$users = $user_result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Handling form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $class_id = $_POST['class_id'];
    $class_date = $_POST['class_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $description = $_POST['description'];
    $diet_plan = $_POST['diet_plan'];
    $selected_user = $_POST['selected_user']; // "all" or a specific user ID

    // Validate time: end time must be after start time
    if (strtotime($end_time) <= strtotime($start_time)) {
        $message = "Error: End time must be after start time.";
    } else {
        // Insert into class_schedule table
        $insert_query = "INSERT INTO class_schedule (trainer_id, class_id, class_date, start_time, end_time, description, diet_plan, user_id) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_query);

        if (!$stmt) {
            die("Error preparing schedule query: " . $conn->error);
        }

        $user_id = ($selected_user === "all") ? null : (int)$selected_user;
        $stmt->bind_param("iisssssi", $trainer_id, $class_id, $class_date, $start_time, $end_time, $description, $diet_plan, $user_id);

        if ($stmt->execute()) {
            $schedule_id = $stmt->insert_id;

            // Send notifications
            if ($selected_user === "all") {
                $notified_users = 0;
                foreach ($users as $user) {
                    $notify_query = "INSERT INTO notifications (user_id, message) VALUES (?, ?)";
                    $notify_stmt = $conn->prepare($notify_query);
                    $msg = "Trainer scheduled a new class: {$classes[array_search($class_id, array_column($classes, 'id'))]['class_name']} on $class_date from $start_time to $end_time. Description: $description. Diet Plan: $diet_plan";
                    $notify_stmt->bind_param("is", $user['id'], $msg);
                    if ($notify_stmt->execute()) {
                        $notified_users++;
                    }
                    $notify_stmt->close();
                }
                $message = "Schedule added and notifications sent to $notified_users booked users successfully!";
            } else {
                $notify_query = "INSERT INTO notifications (user_id, message) VALUES (?, ?)";
                $notify_stmt = $conn->prepare($notify_query);
                $msg = "Trainer scheduled a new class: {$classes[array_search($class_id, array_column($classes, 'id'))]['class_name']} on $class_date from $start_time to $end_time. Description: $description. Diet Plan: $diet_plan";
                $notify_stmt->bind_param("is", $selected_user, $msg);
                if ($notify_stmt->execute()) {
                    $message = "Schedule added and notification sent to the selected user successfully!";
                } else {
                    $message = "Schedule added, but failed to send notification: " . $notify_stmt->error;
                }
                $notify_stmt->close();
            }
        } else {
            $message = "Error scheduling class: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Class Schedule</title>
    <style>
        body { font-family: 'Arial', sans-serif; background-color: #f4f4f9; margin: 0; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; background-color: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1); }
        h2 { text-align: center; color: #007bff; margin-bottom: 20px; }
        label { font-size: 18px; display: block; margin-top: 15px; color: #333; }
        select, input, textarea { width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px; font-size: 16px; box-sizing: border-box; }
        textarea { resize: vertical; }
        button { width: 100%; padding: 12px; margin-top: 20px; background-color: #28a745; color: white; border: none; border-radius: 5px; font-size: 18px; cursor: pointer; }
        button:hover { background-color: #218838; }
        .message { text-align: center; font-size: 18px; margin-top: 15px; padding: 10px; border-radius: 5px; }
        .message.success { color: #155724; background-color: #d4edda; }
        .message.error { color: #721c24; background-color: #f8d7da; }
    </style>
</head>
<body>

    <div class="container">
        <h2>Send Class Schedule</h2>
        
        <?php if ($message): ?>
            <p class="message <?= strpos($message, 'Error') === false ? 'success' : 'error'; ?>"><?= htmlspecialchars($message); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label for="class_id">Class:</label>
            <select name="class_id" id="class_id" required>
                <option value="">Select a class</option>
                <?php foreach ($classes as $class): ?>
                    <option value="<?= $class['id']; ?>"><?= htmlspecialchars($class['class_name']); ?></option>
                <?php endforeach; ?>
            </select>

            <label for="class_date">Date:</label>
            <input type="date" name="class_date" id="class_date" min="<?= date('Y-m-d'); ?>" required>

            <label for="start_time">Start Time:</label>
            <input type="time" name="start_time" id="start_time" required>

            <label for="end_time">End Time:</label>
            <input type="time" name="end_time" id="end_time" required>

            <label for="description">Description:</label>
            <textarea name="description" id="description" rows="4" placeholder="Enter class details..." required></textarea>

            <label for="diet_plan">Diet Plan:</label>
            <textarea name="diet_plan" id="diet_plan" rows="3" placeholder="Enter diet plan..." required></textarea>

            <label for="selected_user">Send to:</label>
            <select name="selected_user" id="selected_user" required>
                <option value="">Select recipient</option>
                <option value="all">All Booked Users (<?= count($users); ?>)</option>
                <?php foreach ($users as $user): ?>
                    <option value="<?= $user['id']; ?>"><?= htmlspecialchars($user['full_name']); ?></option>
                <?php endforeach; ?>
            </select>

            <button type="submit">Send Schedule</button>
        </form>
    </div>

</body>
</html>