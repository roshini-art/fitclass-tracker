<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_attendance'])) {
    $trainer_id = $_SESSION['trainer_id'];
    $student_id = $_POST['student_id'];
    $attendance_days = intval($_POST['attendance_days']);

    if ($attendance_days > 0) {
        // Check if the student already has an entry in trainer_attendance
        $check_sql = "SELECT id FROM trainer_attendance WHERE student_id = ? AND trainer_id = ?";
        $stmt = $conn->prepare($check_sql);
        $stmt->bind_param("ii", $student_id, $trainer_id);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // Update the remaining_days if record exists
            $update_sql = "UPDATE trainer_attendance SET remaining_days = ? WHERE student_id = ? AND trainer_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("iii", $attendance_days, $student_id, $trainer_id);
            $update_stmt->execute();
            $update_stmt->close();
        } else {
            // Insert a new record
            $insert_sql = "INSERT INTO trainer_attendance (student_id, trainer_id, remaining_days) VALUES (?, ?, ?)";
            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->bind_param("iii", $student_id, $trainer_id, $attendance_days);
            $insert_stmt->execute();
            $insert_stmt->close();
        }

        $stmt->close();
    }
}

header("Location: trainer_attendance.php");
exit();
?>
