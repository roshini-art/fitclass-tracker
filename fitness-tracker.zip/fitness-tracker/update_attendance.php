<?php
session_start();
include 'db.php';

if (!isset($_SESSION['trainer_logged_in']) || $_SESSION['trainer_logged_in'] !== true) {
    echo json_encode(["success" => false, "message" => "Unauthorized access"]);
    exit();
}

$trainer_id = $_SESSION['trainer_id'];
$student_id = $_POST['student_id'];
$status = $_POST['status'];
$current_date = date('Y-m-d');

// Check if attendance has already been marked today for this student by this trainer
$check_sql = "SELECT * FROM trainer_attendance WHERE student_id = ? AND trainer_id = ? AND attendance_date = ?";
$check_stmt = $conn->prepare($check_sql);
$check_stmt->bind_param("iis", $student_id, $trainer_id, $current_date);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows > 0) {
    echo json_encode(["success" => false, "message" => "Attendance already marked for today"]);
    exit();
}

// Get remaining days
$get_days_sql = "SELECT remaining_days FROM trainer_attendance WHERE student_id = ? AND trainer_id = ? ORDER BY attendance_date DESC LIMIT 1";
$get_days_stmt = $conn->prepare($get_days_sql);
$get_days_stmt->bind_param("ii", $student_id, $trainer_id);
$get_days_stmt->execute();
$get_days_stmt->bind_result($remaining_days);
$get_days_stmt->fetch();
$get_days_stmt->close();

// Ensure remaining_days is updated properly
if ($remaining_days > 0) {
    $remaining_days -= 1;
}

// Insert attendance record for today
$insert_sql = "INSERT INTO trainer_attendance (student_id, trainer_id, attendance_date, status, remaining_days)
               VALUES (?, ?, ?, ?, ?)";
$insert_stmt = $conn->prepare($insert_sql);
$insert_stmt->bind_param("iissi", $student_id, $trainer_id, $current_date, $status, $remaining_days);
$insert_stmt->execute();
$insert_stmt->close();

// Update payment_status to "completed" when remaining_days reaches 0
if ($remaining_days == 0) {
    $update_payment_sql = "UPDATE bookings SET payment_status = 'completed' WHERE user_id = ? AND trainer_id = ?";
    $update_payment_stmt = $conn->prepare($update_payment_sql);
    $update_payment_stmt->bind_param("ii", $student_id, $trainer_id);
    $update_payment_stmt->execute();
    $update_payment_stmt->close();
}

echo json_encode(["success" => true, "remaining_days" => $remaining_days]);
?>
