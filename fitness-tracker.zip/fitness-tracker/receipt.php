<?php
session_start();
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header("Location: user_login.php");
    exit();
}

include 'db.php';

if (!isset($_GET['booking_id'])) {
    die("Invalid request.");
}

$booking_id = intval($_GET['booking_id']);

// Fetch booking details
$sql = "SELECT b.*, c.class_name, t.name AS trainer_name, u.username 
        FROM bookings b
        JOIN classes c ON b.class_id = c.id
        JOIN trainers t ON b.trainer_id = t.id
        JOIN users u ON b.user_id = u.id
        WHERE b.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Booking not found.");
}

$booking = $result->fetch_assoc();
$stmt->close();
$conn->close();

// Convert timestamp to IST
date_default_timezone_set('Asia/Kolkata');
$booking_time = date('Y-m-d H:i:s', strtotime($booking['created_at']));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Receipt</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f8ff;
            text-align: center;
        }
        .receipt-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1 { color: #333; }
        .btn {
            background-color: #28a745;
            color: white;
            padding: 10px 15px;
            font-size: 1rem;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
            cursor: pointer;
        }
        .btn:hover { background-color: #218838; }
        .print-btn { background-color: #007bff; }
        .print-btn:hover { background-color: #0056b3; }
        .details { text-align: left; margin: 20px auto; width: 90%; }
        .note {
            font-size: 14px;
            color: #ff0000;
            margin-top: 20px;
            padding: 10px;
            background-color: #ffecec;
            border: 1px solid #ff0000;
            border-radius: 5px;
            text-align: left;
        }
    </style>
</head>
<body>

    <div class="receipt-container" id="receipt">
        <h1>Booking Receipt</h1>
        <p><strong>Booking ID:</strong> <?= $booking['id']; ?></p>
        <p><strong>User:</strong> <?= htmlspecialchars($booking['username']); ?></p>
        <p><strong>Trainer:</strong> <?= htmlspecialchars($booking['trainer_name']); ?></p>
        <p><strong>Class:</strong> <?= htmlspecialchars($booking['class_name']); ?></p>
        <p><strong>Package:</strong> <?= ucfirst(htmlspecialchars($booking['package_type'])); ?></p>
        <p><strong>Price:</strong> ₹<?= htmlspecialchars($booking['price']); ?></p>
        <p><strong>Payment Status:</strong> <?= htmlspecialchars($booking['payment_status']); ?></p>
        <p><strong>Booking Time (IST):</strong> <?= $booking_time; ?></p>
        
        <?php if (!empty($booking['payment_proof'])): ?>
            <h3>Payment Proof</h3>
            <img src="uploads/<?= htmlspecialchars($booking['payment_proof']); ?>" alt="Payment Screenshot" width="200">
        <?php endif; ?>

        <div class="note">
            <strong>Note:</strong> You will receive a confirmation message once your booking is verified. This confirmation will be notified within <strong>48 hours</strong>.  
            If you do not receive a confirmation message within 48 hours, please <strong>contact us</strong> immediately.
        </div>
        
        <br>
        <button onclick="printReceipt()" class="btn print-btn">Print Receipt</button>
        <a href="index.php" class="btn">Go to Home</a>
    </div>

    <script>
        function printReceipt() {
            var printContent = document.getElementById("receipt").innerHTML;
            var originalContent = document.body.innerHTML;
            document.body.innerHTML = printContent;
            window.print();
            document.body.innerHTML = originalContent;
        }
    </script>

</body>
</html>
