<?php
session_start();

// Check if trainer is already logged in
if (isset($_SESSION['trainer_logged_in']) && $_SESSION['trainer_logged_in'] === true) {
    header("Location: trainer_dashboard.php");
    exit();
}

// Database connection
include 'db.php';

// Initialize error message
$error_message = "";

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $trainer_id = $_POST['trainer_id'];  // Change variable name to match database column
    $email = $_POST['email'];

    // Validate trainer credentials
    $sql = "SELECT * FROM trainers WHERE id = ? AND email = ?"; // Use 'id' instead of 'trainer_id'
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("is", $trainer_id, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            // Valid trainer
            $trainer = $result->fetch_assoc();
            $_SESSION['trainer_logged_in'] = true;
            $_SESSION['trainer_id'] = $trainer['id'];  // Store 'id' instead of 'trainer_id'
            $_SESSION['trainer_name'] = $trainer['name'];
            header("Location: trainer_dashboard.php");
            exit();
        } else {
            $error_message = "Invalid Trainer ID or Email!";
        }

        $stmt->close();
    } else {
        $error_message = "Error preparing statement: " . $conn->error;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trainer Login</title>
    <style>
        :root {
            --primary: #007bff; /* Blue for buttons and accents */
            --primary-dark: #0056b3; /* Darker blue for hover */
            --error: #dc3545; /* Red for errors */
            --bg: #f4f4f9; /* Light gray background */
            --white: #fff; /* White for container */
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            --text: #333; /* Dark text color */
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: var(--bg);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 1rem;
        }

        .login-container {
            background: var(--white);
            padding: 2rem;
            border-radius: 8px;
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        h1 {
            color: var(--primary);
            margin-bottom: 1.5rem;
            font-size: 1.75rem;
        }

        .error-message {
            color: var(--error);
            margin-bottom: 1rem;
            font-size: 0.9rem;
            font-weight: bold;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        label {
            font-weight: bold;
            color: var(--text);
            text-align: left;
            margin-bottom: 0.25rem;
        }

        input[type="number"],
        input[type="email"] {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        input[type="number"]:focus,
        input[type="email"]:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
        }

        input[type="submit"] {
            background: var(--primary);
            color: var(--white);
            padding: 0.75rem;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        input[type="submit"]:hover {
            background: var(--primary-dark);
        }

        /* Remove number input arrows for cleaner look */
        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        input[type="number"] {
            -moz-appearance: textfield; /* Firefox */
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 1.5rem;
                max-width: 100%;
            }
            h1 {
                font-size: 1.5rem;
            }
            input[type="number"],
            input[type="email"],
            input[type="submit"] {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Trainer Login</h1>
        
        <!-- Display error message -->
        <?php if (!empty($error_message)): ?>
            <div class="error-message"><?= htmlspecialchars($error_message) ?></div>
        <?php endif; ?>

        <form method="POST">
            <label for="trainer_id">Trainer ID:</label>
            <input type="number" name="trainer_id" id="trainer_id" required>

            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>

            <input type="submit" value="Login">
        </form>
    </div>
</body>
</html>