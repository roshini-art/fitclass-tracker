<?php
session_start();
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header("Location: user_login.php");
    exit();
}

date_default_timezone_set('Asia/Kolkata');
include 'db.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from URL
$class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
$trainer_id = isset($_GET['trainer_id']) ? intval($_GET['trainer_id']) : 0;
$package = isset($_GET['package']) ? $_GET['package'] : '';

$user_id = $_SESSION['user_id'];

// ✅ Fetch class details
$sql_class = "SELECT class_name, platinum_price, gold_price, silver_price, 
                     platinum_description, gold_description, silver_description,
                     platinum_duration, gold_duration, silver_duration 
              FROM classes WHERE id = ?";

$stmt_class = $conn->prepare($sql_class);
$stmt_class->bind_param("i", $class_id);
$stmt_class->execute();
$result_class = $stmt_class->get_result();
$class_data = $result_class->fetch_assoc();
$stmt_class->close();

// ✅ Fetch trainer details
$sql_trainer = "SELECT name FROM trainers WHERE id = ?";
$stmt_trainer = $conn->prepare($sql_trainer);
$stmt_trainer->bind_param("i", $trainer_id);
$stmt_trainer->execute();
$result_trainer = $stmt_trainer->get_result();
$trainer_name = ($result_trainer->num_rows > 0) ? $result_trainer->fetch_assoc()['name'] : "Unknown";
$stmt_trainer->close();

// ✅ Check if class exists
if (!$class_data) {
    die("Error: Class not found.");
}

// ✅ Package details with duration
$packages = [
    "silver" => [
        "price" => $class_data['silver_price'],
        "description" => $class_data['silver_description'],
        "duration" => isset($class_data['silver_duration']) ? intval($class_data['silver_duration']) : 0
    ],
    "golden" => [
        "price" => $class_data['gold_price'],
        "description" => $class_data['gold_description'],
        "duration" => isset($class_data['gold_duration']) ? intval($class_data['gold_duration']) : 0
    ],
    "platinum" => [
        "price" => $class_data['platinum_price'],
        "description" => $class_data['platinum_description'],
        "duration" => isset($class_data['platinum_duration']) ? intval($class_data['platinum_duration']) : 0
    ]
];



if (!isset($packages[$package]) || !is_numeric($packages[$package]['price'])) {
    die("Error: Invalid package selected.");
}

$selected_package = $packages[$package];


// ✅ Check if the user has already booked the same class with the same package
// ✅ Check if the user has already booked this class (regardless of package)
// ✅ Check if the user has already booked this class and its status
// ✅ SQL Query to Check Existing Booking Status
$check_sql = "SELECT payment_status FROM bookings WHERE user_id = ? AND class_id = ? ORDER BY created_at DESC LIMIT 1";
$check_stmt = $conn->prepare($check_sql);

// Debugging: Check if query preparation is successful
if (!$check_stmt) {
    die("Query preparation failed: " . $conn->error);
}

$check_stmt->bind_param("ii", $user_id, $class_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();
$existing_booking = $check_result->fetch_assoc();
$check_stmt->close();

// ✅ Check if User Already Booked This Class
if ($existing_booking && in_array($existing_booking['payment_status'], ['Pending', 'Accepted'])) {
    echo "<script>alert('You have already booked this class. You can book again only after your previous booking is completed or rejected.'); window.history.back();</script>";
    exit();
}

// ✅ If no active booking, proceed with the new booking
$insert_sql = "INSERT INTO bookings (user_id, trainer_id, class_id, package_type, price, duration, days, payment_status, start_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending', ?, NOW())";
$insert_stmt = $conn->prepare($insert_sql);

if (!$insert_stmt) {
    die("Insert Query preparation failed: " . $conn->error);
}

$insert_stmt->bind_param("iiisssis", $user_id, $trainer_id, $class_id, $package_type, $price, $duration, $days, $start_date);
$insert_stmt->execute();
$insert_stmt->close();


if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($error_message)) {
    if (!isset($_SESSION['user_id'])) {
        die('Error: User not logged in');
    }

    $start_date = $_POST['start_date'];

    // ✅ Validate the start date (No Sundays + Must be after 5 days)
    $current_date = date('Y-m-d');
    $min_allowed_date = date('Y-m-d', strtotime($current_date . ' +5 days'));

    if ($start_date < $min_allowed_date) {
        $error_message = "Classes can only be booked 5 days in advance. Please select a valid date.";
    }

    $day_of_week = date('l', strtotime($start_date));
    if ($day_of_week == 'Sunday') {
        $error_message = "Classes are not available on Sundays. Please select another date.";
    }

    // ✅ Store duration in the database
    $duration = $selected_package['duration'];

    $payment_proof = "";
    $upload_dir = "uploads/";
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    if (isset($_FILES['payment_screenshot']) && $_FILES['payment_screenshot']['error'] == 0) {
        $file_name = "payment_" . time() . "_" . basename($_FILES["payment_screenshot"]["name"]);
        $target_file = $upload_dir . $file_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        if (in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
            if (move_uploaded_file($_FILES["payment_screenshot"]["tmp_name"], $target_file)) {
                $payment_proof = $file_name;
            } else {
                $error_message = "File upload failed.";
            }
        } else {
            $error_message = "Invalid file type. Only JPG, PNG, and GIF allowed.";
        }
    } else {
        $error_message = "Please upload a payment screenshot.";
    }

    if (!isset($error_message)) {
        $created_at = date('Y-m-d H:i:s');
        
        $price = $selected_package['price']; // Assign the correct price
        $duration = $selected_package['duration']; // Assign duration from package
        $days = $duration; // Assign number of days (if applicable)
        
        // Calculate the end date based on duration
        $end_date = date('Y-m-d', strtotime($start_date . " + $duration days")); 
        $duration_text =  htmlspecialchars($duration);
    
        // Corrected SQL Query
        $book_sql = "INSERT INTO bookings 
                    (user_id, trainer_id, class_id, package_type, price, duration, start_date, payment_status, payment_proof, duration_text) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?)";
    
        $book_stmt = $conn->prepare($book_sql);
    
        if (!$book_stmt) {
            die("SQL Error: " . $conn->error); // Debugging SQL errors
        }
    
        // Binding parameters correctly
        $book_stmt->bind_param("iiisddsss", $user_id, $trainer_id, $class_id, $package, $price, $duration, $start_date, $payment_proof, $duration_text);
    
        if ($book_stmt->execute()) {
            $booking_id = $book_stmt->insert_id;
            header("Location: receipt.php?booking_id=" . $booking_id);
            exit();
        } else {
            $error_message = "Booking failed. Please try again. Error: " . $conn->error;
        }
        $book_stmt->close();
    }
}    

$conn->close();
?>



<script>


document.addEventListener("DOMContentLoaded", function () {
    let dateInput = document.getElementById("start_date");

    function validateDate() {
        let selectedDate = new Date(dateInput.value);
        let today = new Date();
        today.setHours(0, 0, 0, 0); // Normalize to midnight
        let minAllowedDate = new Date();
        minAllowedDate.setDate(today.getDate() + 6); // 6th day from today

        // Prevent selection of past dates
        if (selectedDate < today) {
            alert("You cannot select a past date. Please choose a future date.");
            dateInput.value = "";
            return;
        }

        // Prevent selection of dates within the next 5 days
        if (selectedDate < minAllowedDate) {
            alert("You can book classes only from the 6th day onward. Please select a valid date.");
            dateInput.value = "";
            return;
        }

        // Prevent Sundays dynamically
        if (selectedDate.getDay() === 0) {
            alert("Classes are not available on Sundays. Please select another date.");
            dateInput.value = "";
            return;
        }
    }

    // Set minimum date dynamically
    let today = new Date();
    today.setDate(today.getDate() + 6);
    dateInput.setAttribute("min", today.toISOString().split("T")[0]);

    // Validate the date on change
    dateInput.addEventListener("change", validateDate);
});


    function setupDateRestrictions() {
        let dateInput = document.getElementById("start_date");
        let today = new Date();

        // Block all past dates
        let todayStr = today.toISOString().split("T")[0];

        // Move to the 6th day from today
        today.setDate(today.getDate() + 6);
        let minDate = today.toISOString().split("T")[0];

        // Set min date dynamically
        dateInput.setAttribute("min", minDate);

        dateInput.addEventListener("change", function () {
            let selectedDate = new Date(this.value);
            let allowedDate = new Date();
            allowedDate.setDate(new Date().getDate() + 6); // 6th day from today

            // Prevent selection of past dates or the next 5 days
            if (selectedDate < allowedDate) {
                alert("You can book classes only from the 6th day onward. Please select a valid date.");
                this.value = "";
                return;
            }

            // Prevent Sundays dynamically
            if (selectedDate.getDay() === 0) {
                alert("Classes are not available on Sundays. Please select another date.");
                this.value = "";
                return;
            }
        });
    }
</script>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Package Booking Confirmation</title>
    <script>
        function disableSundays() {
            let dateInput = document.getElementById("start_date");
            dateInput.addEventListener("change", function () {
                let selectedDate = new Date(this.value);
                if (selectedDate.getDay() === 0) {
                    alert("Classes are not available on Sundays. Please select another date.");
                    this.value = "";
                }
            });
        }
    </script>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f0f8ff; text-align: center; }
        .container { max-width: 500px; margin: 50px auto; padding: 20px; background-color: #fff; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        .btn { background-color: #28a745; color: white; padding: 10px 20px; font-size: 1rem; border-radius: 5px; text-decoration: none; cursor: pointer; border: none; }
        .btn:hover { background-color: #218838; }
        .error { color: red; }
    </style>
</head>
<body onload="disableSundays()">
<body onload="setupDateRestrictions()">

    <div class="container">
    <a href="your_booking.php">My Bookings</a>

        <h1>Booking Details</h1>
        <p><strong>Trainer Name:</strong> <?= htmlspecialchars($trainer_name); ?></p>
        <p><strong>Class Name:</strong> <?= htmlspecialchars($class_data['class_name']); ?></p>
        
        <h2>Selected Package: <?= ucfirst($package); ?></h2>
<p>Price: ₹<?= htmlspecialchars($selected_package['price']); ?></p>
<p>Duration: <?= htmlspecialchars($selected_package['duration']); ?> Days</p>
<p><strong>Description:</strong> <?= htmlspecialchars($selected_package['description']); ?></p>


        <p><strong>Description:</strong> <?= htmlspecialchars($selected_package['description']); ?></p>

        
        <h3>Payment</h3>
            <p>Please scan the QR code below to make the payment:</p>
            <img src="uploads/download.png" alt="Google Pay QR Code" width="200" height="200">

        <form method="POST" enctype="multipart/form-data">
        <label>Start Date:</label><br>
        <input type="date" name="start_date" id="start_date" required><br><br>

        

            <label>Upload Payment Screenshot:</label><br>
            <input type="file" name="payment_screenshot" accept="image/*" required><br><br>
            <?php if (isset($error_message)): ?>
    <p class="error"><?= htmlspecialchars($error_message); ?></p>
<?php endif; ?>
            <button type="submit" class="btn">Confirm Booking</button>
        </form>
    </div>
    


</body>
</html>
