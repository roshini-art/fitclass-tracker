<?php
session_start();
include 'db.php';

if (!isset($_SESSION['trainer_logged_in']) || $_SESSION['trainer_logged_in'] !== true) {
    header("Location: trainer_login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['set_attendance'])) {
    $trainer_id = $_SESSION['trainer_id'];
    $student_id = $_POST['student_id'];
    $attendance_days = $_POST['attendance_days'];

    $sql = "INSERT INTO trainer_attendance (trainer_id, student_id, remaining_days, added_at) 
            VALUES (?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE remaining_days = remaining_days + VALUES(remaining_days)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $trainer_id, $student_id, $attendance_days);
    if ($stmt->execute()) {
        header("Location: trainer_attendance.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
    $stmt->close();
}
