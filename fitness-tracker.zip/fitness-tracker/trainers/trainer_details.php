<?php
// Database connection
$servername = "localhost";
$username = "root"; // Adjust according to your database credentials
$password = ""; // Adjust according to your database credentials
$dbname = "fitness_booking";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get class_id from query parameter
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;

$sql = "SELECT name, specialization, contact_number, email, image, start_time, end_time 
        FROM trainers 
        WHERE class_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $class_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trainer Details</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 20px;
            padding: 0;
            background: linear-gradient(to right, #f8f9fa, #e9ecef);
            color: #333;
        }

        h1 {
            text-align: center;
            color: #007bff;
            margin-bottom: 30px;
        }

        .trainer-card {
            display: flex;
            align-items: center;
            gap: 20px;
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .trainer-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 12px rgba(0, 0, 0, 0.2);
        }

        .trainer-card img {
            border-radius: 10px;
            width: 150px;
            height: 150px;
            object-fit: cover;
        }

        .trainer-card h3 {
            margin: 0 0 10px;
            color: #333;
            font-size: 1.5rem;
        }

        .trainer-card p {
            margin: 5px 0;
            font-size: 1rem;
            color: #555;
        }

        a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: #ffffff;
            font-weight: bold;
            border-radius: 5px;
            text-decoration: none;
            text-align: center;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        a:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        @media (max-width: 768px) {
            .trainer-card {
                flex-direction: column;
                align-items: flex-start;
            }

            .trainer-card img {
                width: 100%;
                height: auto;
            }

            .trainer-card div {
                width: 100%;
            }
        }
    </style>
</head>

<body>
    <h1>Trainer Details</h1>
    <div>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $imagePath = 'uploads/' . htmlspecialchars($row['image']);
                echo '<div class="trainer-card">
                        <img src="' . $imagePath . '" alt="' . htmlspecialchars($row['name']) . '">
                        <div>
                            <h3>' . htmlspecialchars($row['name']) . '</h3>
                            <p><strong>Specialization:</strong> ' . htmlspecialchars($row['specialization']) . '</p>
                            <p><strong>Contact:</strong> ' . htmlspecialchars($row['contact_number']) . '</p>
                            <p><strong>Email:</strong> ' . htmlspecialchars($row['email']) . '</p>
                            <p><strong>Start Time:</strong> ' . htmlspecialchars($row['start_time']) . '</p>
                            <p><strong>End Time:</strong> ' . htmlspecialchars($row['end_time']) . '</p>
                        </div>
                      </div>';
            }
        } else {
            echo "<p style='text-align: center; color: #555;'>No trainers available for this class.</p>";
        }

        $stmt->close();
        $conn->close();
        ?>
    </div>
    <div style="text-align: center;">
        <a href="index.php">Back to Classes</a>
    </div>
</body>

</html>
