<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fitness_booking";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session
session_start();

// Check if trainer is logged in
if (!isset($_SESSION['trainer_id'])) {
    header("Location: login.php");
    exit();
}

$trainer_id = $_SESSION['trainer_id'];

// Fetch classes assigned to the trainer
$sql = "SELECT 
            classes.id AS class_id, 
            classes.class_name, 
            trainer_class_details.timing, 
            trainer_class_details.description 
        FROM classes 
        LEFT JOIN trainer_class_details 
        ON classes.id = trainer_class_details.class_id 
        AND trainer_class_details.trainer_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $trainer_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trainer Dashboard</title>
    <style>
        /* Styling for table and buttons */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        .btn {
            padding: 8px 12px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Trainer Dashboard</h1>
    <table>
        <thead>
            <tr>
                <th>Class Name</th>
                <th>Timing</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>" . htmlspecialchars($row['class_name']) . "</td>
                        <td>" . htmlspecialchars($row['timing'] ?? 'Not Set') . "</td>
                        <td>" . htmlspecialchars($row['description'] ?? 'Not Set') . "</td>
                        <td>
                            <a href='add_details.php?class_id=" . $row['class_id'] . "' class='btn'>Add/Edit Details</a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No classes assigned.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
