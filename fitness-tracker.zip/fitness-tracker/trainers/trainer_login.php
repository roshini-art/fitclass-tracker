<?php
session_start();
$conn = new mysqli("localhost", "root", "", "fitness_booking");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM trainers WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $trainer = $result->fetch_assoc();
        if (password_verify($password, $trainer['password'])) {
            $_SESSION['trainer_id'] = $trainer['id'];
            header("Location: trainer_dashboard.php");
            exit;
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "Trainer not found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Trainer Login</title>
</head>
<body>
    <form method="POST">
        <h2>Trainer Login</h2>
        <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
</body>
</html>
