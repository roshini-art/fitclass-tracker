<?php
session_start();
include 'db.php';

if (!isset($_SESSION['trainer_id'])) {
    header("Location: trainer_login.php");
    exit();
}

$trainer_id = $_SESSION['trainer_id'];

// Fetch trainer details
$sql_trainer = "SELECT name FROM trainers WHERE id = ?";
$stmt = $conn->prepare($sql_trainer);
$stmt->bind_param("i", $trainer_id);
$stmt->execute();
$result_trainer = $stmt->get_result();
$trainer = $result_trainer->fetch_assoc();
$trainer_name = $trainer['name'];

// Fetch all assigned users for this trainer
$sql = "SELECT 
            users.username, users.email, users.phone, 
            classes.class_name, 
            bookings.package_type, bookings.price, bookings.payment_status, 
            class_schedule.class_date, class_schedule.start_time, class_schedule.end_time
        FROM bookings
        JOIN users ON bookings.user_id = users.id
        JOIN classes ON bookings.class_id = classes.id
        JOIN class_schedule ON bookings.class_id = class_schedule.class_id
        WHERE bookings.trainer_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $trainer_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Trainer Dashboard</title>
</head>
<body>

<h2>Welcome, <?php echo htmlspecialchars($trainer_name); ?></h2>
<a href="trainer_logout.php">Logout</a>

<h3>Assigned Users</h3>
<table border="1">
    <tr>
        <th>User Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Class Name</th>
        <th>Package</th>
        <th>Price</th>
        <th>Date</th>
        <th>Time</th>
        <th>Booking Status</th>
    </tr>
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . htmlspecialchars($row['username']) . "</td>
                    <td>" . htmlspecialchars($row['email']) . "</td>
                    <td>" . htmlspecialchars($row['phone']) . "</td>
                    <td>" . htmlspecialchars($row['class_name']) . "</td>
                    <td>" . htmlspecialchars($row['package_type']) . "</td>
                    <td>" . htmlspecialchars($row['price']) . "</td>
                    <td>" . htmlspecialchars($row['class_date']) . "</td>
                    <td>" . htmlspecialchars($row['start_time']) . " - " . htmlspecialchars($row['end_time']) . "</td>
                    <td>" . htmlspecialchars($row['payment_status']) . "</td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='9'>No assigned users found.</td></tr>";
    }
    ?>
</table>

</body>
</html>
