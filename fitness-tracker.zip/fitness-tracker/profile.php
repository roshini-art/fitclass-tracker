<?php
// Start session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit();
}

// Database connection
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "fitness_booking";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user details
$user = $_SESSION['username'];
$sql = "SELECT id, username, email, full_name, phone, dob FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $userData = $result->fetch_assoc();
    $user_id = $userData['id']; // Get user ID for fetching bookings
} else {
    echo "No user found";
    exit();
}
$stmt->close();

// Fetch user bookings
$sql_bookings = "SELECT b.id, c.class_name, t.name AS trainer_name, b.package_type, b.price, b.payment_status, b.created_at 
                 FROM bookings b
                 JOIN classes c ON b.class_id = c.id
                 JOIN trainers t ON b.trainer_id = t.id
                 WHERE b.user_id = ? 
                 ORDER BY b.created_at DESC";

$stmt_bookings = $conn->prepare($sql_bookings);
$stmt_bookings->bind_param("i", $user_id);
$stmt_bookings->execute();
$result_bookings = $stmt_bookings->get_result();

// Fetch unread notifications
$sql_notifications = "SELECT id, message FROM notifications WHERE user_id = ? AND status = 'unread' ORDER BY created_at DESC";
$stmt_notifications = $conn->prepare($sql_notifications);
$stmt_notifications->bind_param("i", $user_id);
$stmt_notifications->execute();
$result_notifications = $stmt_notifications->get_result();

// Mark notifications as read after fetching
$update_notif_sql = "UPDATE notifications SET status = 'read' WHERE user_id = ?";
$stmt_update_notif = $conn->prepare($update_notif_sql);
$stmt_update_notif->bind_param("i", $user_id);
$stmt_update_notif->execute();

// Fetch unread trainer messages
$sql_trainer_messages = "SELECT message FROM trainer_messages WHERE user_id = ? AND status = 'unread' ORDER BY created_at DESC";
$stmt_trainer_messages = $conn->prepare($sql_trainer_messages);
$stmt_trainer_messages->bind_param("i", $user_id);
$stmt_trainer_messages->execute();
$result_trainer_messages = $stmt_trainer_messages->get_result();

// Mark trainer messages as read after fetching
$update_trainer_msg_sql = "UPDATE trainer_messages SET status = 'read' WHERE user_id = ?";
$stmt_update_trainer_msg = $conn->prepare($update_trainer_msg_sql);
$stmt_update_trainer_msg->bind_param("i", $user_id);
$stmt_update_trainer_msg->execute();



// Fetch class schedule details, including diet_plan
$sql_schedule = "SELECT cs.class_date, cs.start_time, cs.end_time, cs.description, cs.diet_plan, 
                        c.class_name, t.name AS trainer_name
                 FROM class_schedule cs
                 JOIN classes c ON cs.class_id = c.id
                 JOIN trainers t ON cs.trainer_id = t.id
                 WHERE cs.user_id IS NULL OR cs.user_id = ?
                 ORDER BY cs.class_date ASC, cs.start_time ASC";

$stmt_schedule = $conn->prepare($sql_schedule);
$stmt_schedule->bind_param("i", $user_id);
$stmt_schedule->execute();
$result_schedule = $stmt_schedule->get_result();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
        /* Existing Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f8ff;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            font-size: 2rem;
            margin-bottom: 20px;
        }

        .profile-details label {
            font-weight: bold;
        }

        .profile-details p {
            margin: 5px 0;
        }

        .btn {
            background-color: #ff6347;
            color: white;
            padding: 10px 20px;
            font-size: 1rem;
            border-radius: 5px;
            text-decoration: none;
            text-align: center;
            display: inline-block;
            margin-right: 10px;
        }

        .btn:hover {
            background-color: #ff4500;
        }

        .logout-btn {
            background-color: #dc143c;
            text-decoration: none;
            padding: 10px 20px;
            font-size: 1rem;
            color: white;
            border-radius: 5px;
            text-align: center;
            display: inline-block;
        }

        .logout-btn:hover {
            background-color: #b22222;
        }

        /* Booking Table */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        .status-pending {
            color: orange;
            font-weight: bold;
        }

        .status-accepted {
            color: green;
            font-weight: bold;
        }

        .status-rejected {
            color: red;
            font-weight: bold;
        }

        .status-completed {
            color: blue;
            font-weight: bold;
        }

        /* Notification Styles */
        .notification-section {
            background: #fff3cd;
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
            border: 1px solid #ffeeba;
        }

        .notification-section h3 {
            margin: 0 0 10px;
        }

        .notification-list li {
            background: #f9f9f9;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            list-style: none;
        }
        
        /* New Styles for Trainer Messages */
        .trainer-messages {
            background: #e3f2fd;
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
            border: 1px solid #90caf9;
        }

        .trainer-messages h3 {
            margin: 0 0 10px;
            color: #1565c0;
        }

        .message-list li {
            background: #ffffff;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            list-style: none;
            border-left: 5px solid #1e88e5;
        }
        .trainer-messages {
        position: relative;
        background: #e3f2fd;
        padding: 15px;
        margin: 20px 0;
        border-radius: 5px;
        border: 1px solid #90caf9;
    }

    .trainer-messages h3 {
        margin: 0 0 10px;
        color: #1565c0;
    }

    .message-list li {
        background: #ffffff;
        padding: 10px;
        margin: 5px 0;
        border-radius: 5px;
        list-style: none;
        border-left: 5px solid #1e88e5;
    }

    .close-btn {
        position: absolute;
        top: 10px;
        right: 10px;
        background: #ff6347;
        border: none;
        color: white;
        font-size: 16px;
        padding: 5px 10px;
        cursor: pointer;
        border-radius: 50%;
    }

    .close-btn:hover {
        background: #ff4500;
    }
    .close-btn {
    position: absolute;
    top: 5px;
    right: 10px;
    background: red;
    color: white;
    font-size: 18px;
    font-weight: bold;
    border: none;
    padding: 5px 10px;
    cursor: pointer;
    border-radius: 50%;
    line-height: 18px;
    text-align: center;
}

.close-btn:hover {
    background: darkred;
}

.trainer-messages {
    border: 2px solid red; /* Debugging */
}


    </style>
</head>

<body>
    <div class="container">
        <h2>User Profile</h2>

        <div class="profile-details">
            <label>Username:</label>
            <p><?php echo htmlspecialchars($userData['username']); ?></p>

            <label>Email:</label>
            <p><?php echo htmlspecialchars($userData['email']); ?></p>

            <label>Full Name:</label>
            <p><?php echo htmlspecialchars($userData['full_name']); ?></p>

            <label>Phone:</label>
            <p><?php echo htmlspecialchars($userData['phone']); ?></p>

            <label>Date of Birth:</label>
            <p><?php echo htmlspecialchars($userData['dob']); ?></p>
        </div>

        <!-- Buttons -->
        <a href="update_profile.php" class="btn">Update Profile</a>
        <a href="user_attendance.php" class="btn">view Attendance</a>

        <a href="fitness_tracking.php" class="btn">Fitness Tracking</a>
        <a href="user_logout.php" class="logout-btn">Logout</a>

   <!-- Notifications Section -->
<?php if ($result_notifications->num_rows > 0): ?>
    <div class="notification-section" id="notification-section">
        <h3>Notifications</h3>
        <ul class="notification-list">
            <?php while ($notif = $result_notifications->fetch_assoc()): ?>
                <li>
                    <?= htmlspecialchars($notif['message']); ?>
                    <button class="close-btn" onclick="closeItem(this)">&#10006;</button>
                </li>
            <?php endwhile; ?>
        </ul>
    </div>

    
<?php endif; ?>



<!-- Class Schedule Details -->
<h2>Class Schedule</h2>
<table>
    <thead>
        <tr>
            <th>Class Name</th>
            <th>Trainer</th>
            <th>Date</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Description</th>
            <th>Diet Plan</th>  <!-- New column added -->
        </tr>
    </thead>
    <tbody>
        <?php if ($result_schedule->num_rows > 0): ?>
            <?php while ($row = $result_schedule->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['class_name']); ?></td>
                    <td><?= htmlspecialchars($row['trainer_name']); ?></td>
                    <td><?= htmlspecialchars($row['class_date']); ?></td>
                    <td><?= htmlspecialchars($row['start_time']); ?></td>
                    <td><?= htmlspecialchars($row['end_time']); ?></td>
                    <td><?= htmlspecialchars($row['description']); ?></td>
                    <td><?= htmlspecialchars($row['diet_plan']); ?></td> <!-- Display diet plan -->
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="7" style="text-align: center;">No class schedules available</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

    </div>

<!-- Trainer Messages Section -->
<?php if ($result_trainer_messages->num_rows > 0): ?>
    <div class="trainer-messages" id="trainer-messages">
        <h3>Messages from Trainer</h3>
        <ul class="message-list">
            <?php while ($msg = $result_trainer_messages->fetch_assoc()): ?>
                <li>
                    <?= htmlspecialchars($msg['message']); ?>
                    <button class="close-btn" onclick="closeItem(this)">&#10006;</button>
                </li>
            <?php endwhile; ?>
        </ul>
    </div>
<?php endif; ?>

<style>
    .notification-section, .trainer-messages {
        position: relative;
        padding: 15px;
        margin: 20px 0;
        border-radius: 5px;
        border: 1px solid #ccc;
    }

    .notification-section {
        background: #fff3cd;
        border: 1px solid #ffeeba;
    }

    .trainer-messages {
        background: #e3f2fd;
        border: 1px solid #90caf9;
    }

    .notification-section h3, .trainer-messages h3 {
        margin: 0 0 10px;
    }

    .notification-list, .message-list {
        list-style: none;
        padding: 0;
    }

    .notification-list li, .message-list li {
        position: relative;
        padding: 10px;
        margin-bottom: 5px;
        border: 1px solid #ddd;
        border-radius: 5px;
        background: #fff;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .close-btn {
        background: red;
        color: white;
        font-size: 14px;
        font-weight: bold;
        border: none;
        padding: 5px;
        cursor: pointer;
        border-radius: 50%;
        width: 25px;
        height: 25px;
        text-align: center;
        line-height: 15px;
    }

    .close-btn:hover {
        background: darkred;
    }
</style>

<script>
    function closeItem(btn) {
        btn.parentElement.style.display = "none";  // Hide the specific notification/message
    }
</script>

<!-- Trainer Messages Section -->
<?php if ($result_trainer_messages->num_rows > 0): ?>
    <div class="trainer-messages" id="trainer-messages">
        <button class="close-btn" onclick="closeTrainerMessages()">&#10006;</button>
        <h3>Messages from Trainer</h3>
        <ul class="message-list">
            <?php while ($msg = $result_trainer_messages->fetch_assoc()): ?>
                <li><?= htmlspecialchars($msg['message']); ?></li>
            <?php endwhile; ?>
        </ul>
    </div>
<?php endif; ?>

<script>
    function closeNotifications() {
        document.getElementById("notification-section").style.display = "none";
    }

    function closeTrainerMessages() {
        document.getElementById("trainer-messages").style.display = "none";
    }
</script>


 <!-- Trainer Messages Section -->
<?php if ($result_trainer_messages->num_rows > 0): ?>
    <div class="trainer-messages" id="trainer-messages">
    <button class="close-btn" onclick="closeTrainerMessages()">&#10006;</button>
    <h3>Messages from Trainer</h3>
    <ul class="message-list">
        <?php while ($msg = $result_trainer_messages->fetch_assoc()): ?>
            <li><?= htmlspecialchars($msg['message']); ?></li>
        <?php endwhile; ?>
    </ul>
</div>

<?php endif; ?>

<script>
    function closeTrainerMessages() {
    document.getElementById("trainer-messages").style.display = "none";
}

</script>


        <!-- User Booking Details -->
        <h2>Your Bookings</h2>
        <table>
            <thead>
                <tr>
                    <th>Class</th>
                    <th>Trainer</th>
                    <th>Package</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Booked On</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result_bookings->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['class_name']); ?></td>
                        <td><?= htmlspecialchars($row['trainer_name']); ?></td>
                        <td><?= ucfirst(htmlspecialchars($row['package_type'])); ?></td>
                        <td>₹<?= htmlspecialchars($row['price']); ?></td>
                        <td class="status-<?= strtolower(htmlspecialchars($row['payment_status'])); ?>">
                            <?= ucfirst(htmlspecialchars($row['payment_status'])); ?>
                        </td>
                        <td><?= htmlspecialchars($row['created_at']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>