<?php
session_start();
include 'db.php';

// Ensure trainer is logged in
if (!isset($_SESSION['trainer_logged_in']) || $_SESSION['trainer_logged_in'] !== true) {
    echo json_encode(["success" => false, "message" => "Unauthorized Access"]);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!isset($_POST['student_id']) || !isset($_POST['trainer_id'])) {
        echo json_encode(["success" => false, "message" => "Invalid request!"]);
        exit();
    }

    $student_id = $_POST['student_id'];
    $trainer_id = $_POST['trainer_id'];

    error_log("Complete Booking Request: student_id=$student_id, trainer_id=$trainer_id");


    // Update the booking status to "Completed"
    $updateQuery = "UPDATE bookings SET payment_status = 'Completed' WHERE user_id = ? AND trainer_id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ii", $student_id, $trainer_id);
    
    if ($stmt->execute()) {
        // Delete from trainer_attendance table
        $deleteQuery = "DELETE FROM trainer_attendance WHERE student_id = ? AND trainer_id = ?";
        $stmt2 = $conn->prepare($deleteQuery);
        $stmt2->bind_param("ii", $student_id, $trainer_id);
        
        if ($stmt2->execute()) {
            echo json_encode(["success" => true, "message" => "Booking marked as completed and removed."]);
        } else {
            echo json_encode(["success" => false, "message" => "Error removing attendance record."]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "Error updating booking status."]);
    }

    $stmt->close();
    $stmt2->close();
    $conn->close();
}
?>
<script>
function completeBooking(studentId, trainerId, buttonElement) {
    if (!confirm("Are you sure you want to mark this booking as completed?")) return;

    fetch('complete_booking.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `student_id=${studentId}&trainer_id=${trainerId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Booking marked as completed!");
            buttonElement.closest('tr').remove(); // Remove row from table
        } else {
            alert(data.message || "Error completing booking!");
        }
    })
    .catch(error => console.error("Error:", error));
}
</script>
