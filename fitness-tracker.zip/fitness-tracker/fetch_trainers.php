<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fitness_booking";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;

if ($class_id > 0) {
    $sql = "SELECT name, specialization, contact_number, email, image, start_time, end_time 
            FROM trainers WHERE class_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $class_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<div class="trainer-details">
                    <img src="uploads/' . htmlspecialchars($row['image']) . '" alt="Trainer Image">
                    <h4>' . htmlspecialchars($row['name']) . '</h4>
                    <p>Specialization: ' . htmlspecialchars($row['specialization']) . '</p>
                    <p>Contact: ' . htmlspecialchars($row['contact_number']) . '</p>
                    <p>Email: ' . htmlspecialchars($row['email']) . '</p>
                    <p>Timing: ' . htmlspecialchars($row['start_time']) . ' - ' . htmlspecialchars($row['end_time']) . '</p>
                  </div>';
        }
    } else {
        echo "<p>No trainers available for this class.</p>";
    }

    $stmt->close();
} else {
    echo "<p>Invalid class ID.</p>";
}

$conn->close();
?>
