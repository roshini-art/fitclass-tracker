<?php
session_start();
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header("Location: user_login.php");
    exit();
}

// Database connection
include 'db.php';

// Get class_id and trainer_id from the URL
$class_id = isset($_GET['class_id']) ? $_GET['class_id'] : 0;
$trainer_id = isset($_GET['trainer_id']) ? $_GET['trainer_id'] : 0;

// Fetch trainer details
$sql_trainer = "SELECT name FROM trainers WHERE id = ?";
$stmt_trainer = $conn->prepare($sql_trainer);
$stmt_trainer->bind_param("i", $trainer_id);
$stmt_trainer->execute();
$result_trainer = $stmt_trainer->get_result();
$trainer_name = $result_trainer->num_rows > 0 ? $result_trainer->fetch_assoc()['name'] : "Unknown";
$stmt_trainer->close();

// Fetch class details including name, description, prices, durations, and descriptions
$sql_class = "SELECT class_name, description, 
                     platinum_price, gold_price, silver_price, 
                     platinum_description, gold_description, silver_description,
                     platinum_duration, gold_duration, silver_duration 
              FROM classes WHERE id = ?";
$stmt_class = $conn->prepare($sql_class);
$stmt_class->bind_param("i", $class_id);
$stmt_class->execute();
$result_class = $stmt_class->get_result();
$class_data = $result_class->fetch_assoc();
$stmt_class->close();

// If class data is not found, set default values
if (!$class_data) {
    $class_data = [
        "class_name" => "Unknown",
        "description" => "No description available",
        "platinum_price" => "Not available",
        "gold_price" => "Not available",
        "silver_price" => "Not available",
        "platinum_description" => "Not available",
        "gold_description" => "Not available",
        "silver_description" => "Not available",
        "platinum_duration" => 0,
        "gold_duration" => 0,
        "silver_duration" => 0
    ];
}

// Mapping package names to database fields dynamically
$packages = [
    "silver" => [
        "price" => $class_data['silver_price'],
        "description" => $class_data['silver_description'],
        "duration" => $class_data['silver_duration'] . " Days"
    ],
    "golden" => [
        "price" => $class_data['gold_price'],
        "description" => $class_data['gold_description'],
        "duration" => $class_data['gold_duration'] . " Days"
    ],
    "platinum" => [
        "price" => $class_data['platinum_price'],
        "description" => $class_data['platinum_description'],
        "duration" => $class_data['platinum_duration'] . " Days"
    ]
];

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Package Details</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .container { max-width: 800px; margin: auto; }
        h1, h2 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: center; }
        th { background-color: #f4f4f4; }
        .btn { text-decoration: none; background-color: green; color: white; padding: 5px 10px; }
        .disabled-btn { color: gray; }
    </style>
</head>
<body>

<div class="container">
    <h1>Class Details</h1>
    <h2><?= htmlspecialchars($class_data['class_name']); ?></h2>
    <p><strong>Description:</strong> <?= htmlspecialchars($class_data['description']); ?></p>

    <h2>Package Details for Trainer: <?= htmlspecialchars($trainer_name); ?></h2>

    <table>
        <thead>
            <tr>
                <th>Package Name</th>
                <th>Price</th>
                <th>Duration</th>
                <th>Description</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($packages as $key => $package): ?>
                <tr>
                    <td><?= ucfirst($key); ?></td>
                    <td><?= is_numeric($package['price']) ? "₹" . htmlspecialchars($package['price']) : "Not available"; ?></td>
                    <td><?= htmlspecialchars($package['duration']); ?></td>
                    <td><?= htmlspecialchars($package['description']); ?></td>
                    <td>
                        <?php if (is_numeric($package['price'])): ?>
                            <a href="confirm_booking.php?class_id=<?= $class_id; ?>&trainer_id=<?= $trainer_id; ?>&package=<?= $key; ?>" class="btn">Confirm Booking</a>
                        <?php else: ?>
                            <span class="disabled-btn">Not Available</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>
