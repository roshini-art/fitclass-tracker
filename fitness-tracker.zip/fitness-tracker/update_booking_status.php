<?php
session_start();
include 'db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_SESSION['trainer_logged_in']) || $_SESSION['trainer_logged_in'] !== true) {
        echo json_encode(["success" => false, "message" => "Unauthorized access."]);
        exit;
    }

    $trainer_id = $_POST['trainer_id'];
    $student_id = $_POST['student_id'];

    // Check if the trainer is authorized to complete this student's booking
    $check_sql = "SELECT * FROM bookings WHERE user_id = ? AND trainer_id = ? AND payment_status = 'Accepted'";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("ii", $student_id, $trainer_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        echo json_encode(["success" => false, "message" => "No active booking found or already completed."]);
        exit;
    }

    // Update the status to "Completed"
    $update_sql = "UPDATE bookings SET payment_status = 'Completed' WHERE user_id = ? AND trainer_id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("ii", $student_id, $trainer_id);

    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => "Database update failed."]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["success" => false, "message" => "Invalid request."]);
}
?>
