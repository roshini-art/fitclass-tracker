<?php
session_start();
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header("Location: user_login.php");
    exit();
}

include 'db.php';

$user_id = $_SESSION['user_id'];

$sql = "SELECT b.id, c.class_name, t.name AS trainer_name, b.package_type, 
               b.price, b.start_date, b.payment_status
        FROM bookings b
        JOIN classes c ON b.class_id = c.id
        JOIN trainers t ON b.trainer_id = t.id
        WHERE b.user_id = ?
        ORDER BY b.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Bookings</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f0f8ff; text-align: center; }
        .container { max-width: 800px; margin: 50px auto; padding: 20px; background-color: #fff; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; }
        th { background-color: #28a745; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Your Bookings</h1>
        <table>
            <tr>
                <th>Class Name</th>
                <th>Trainer</th>
                <th>Package</th>
                <th>Price</th>
                <th>Start Date</th>
                <th>Status</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['class_name']); ?></td>
                    <td><?= htmlspecialchars($row['trainer_name']); ?></td>
                    <td><?= ucfirst(htmlspecialchars($row['package_type'])); ?></td>
                    <td>₹<?= htmlspecialchars($row['price']); ?></td>
                    <td><?= htmlspecialchars($row['start_date']); ?></td>
                    <td><?= htmlspecialchars($row['payment_status']); ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>
