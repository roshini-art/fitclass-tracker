<?php
session_start();
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header("Location: user_login.php");  // Redirect to user login page
    exit();
}

// Database connection
include 'db.php';

// Get the class ID from the URL
$class_id = isset($_GET['class_id']) ? $_GET['class_id'] : 0;

// Fetch the class name for the selected class
$sql_class = "SELECT class_name FROM classes WHERE id = ?";
$stmt_class = $conn->prepare($sql_class);
$stmt_class->bind_param("i", $class_id);
$stmt_class->execute();
$result_class = $stmt_class->get_result();
$class_name = "";

if ($result_class->num_rows > 0) {
    $row_class = $result_class->fetch_assoc();
    $class_name = $row_class['class_name'];
}

// Fetch trainers for the selected class including shift_timings
$sql = "SELECT t.id, t.name, t.specialization, t.contact_number, t.email, t.image, t.shift_timings 
        FROM trainers t 
        WHERE t.class_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $class_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Trainers</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        h1 { color: #333; }
        nav { margin-bottom: 20px; }
        nav a { text-decoration: none; margin-right: 15px; color: #007bff; font-size: 18px; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #007bff; color: white; }
        img { border-radius: 5px; }
        .btn { display: inline-block; padding: 8px 12px; color: white; background: green; text-decoration: none; border-radius: 5px; }
        .btn:hover { background: darkgreen; }
    </style>
</head>
<body>

    <h1>Trainers for Class: <?= htmlspecialchars($class_name); ?></h1>

    <nav>
        <a href="user_dashboard.php">User Dashboard</a>
        <a href="view_classes.php">View Classes</a>
    </nav>

    <div class="container">
        <h2>Available Trainers</h2>

        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Specialization</th>
                        <th>Contact Number</th>
                        <th>Email</th>
                        <th>Image</th>
                        <th>Shift Timings</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['name']); ?></td>
                            <td><?= htmlspecialchars($row['specialization']); ?></td>
                            <td><?= htmlspecialchars($row['contact_number']); ?></td>
                            <td><?= htmlspecialchars($row['email']); ?></td>
                            <td>
                                <img src="uploads/<?= htmlspecialchars($row['image']); ?>" alt="Trainer Image" width="50" height="50">
                            </td>
                            <td><?= htmlspecialchars($row['shift_timings']); ?></td>
                            <td>
                                <a href="package_details.php?class_id=<?= $class_id; ?>&trainer_id=<?= $row['id']; ?>" class="btn">Book</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No trainers available for this class.</p>
        <?php endif; ?>
    </div>

</body>
</html>

<?php
$stmt_class->close();
$stmt->close();
$conn->close();
?>
