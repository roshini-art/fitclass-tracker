<?php
session_start();
include 'db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle booking approval/rejection
if (isset($_GET['booking_id']) && isset($_GET['action'])) {
    $booking_id = $_GET['booking_id'];
    $action = $_GET['action'];
    
    if ($action == 'accept' || $action == 'reject' || $action == 'complete') {
        $status = ($action == 'accept') ? 'Accepted' : (($action == 'reject') ? 'Rejected' : 'Complete');
        $update_sql = "UPDATE bookings SET payment_status = ? WHERE id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("si", $status, $booking_id);
        
        if ($stmt->execute() && $action == 'accept') {
            // Fetch user ID from the booking
            $fetch_user_sql = "SELECT user_id FROM bookings WHERE id = ?";
            $stmt_user = $conn->prepare($fetch_user_sql);
            $stmt_user->bind_param("i", $booking_id);
            $stmt_user->execute();
            $result_user = $stmt_user->get_result();
            $user = $result_user->fetch_assoc();
            $user_id = $user['user_id'];

            // Insert notification
            $message = "Your booking has been accepted. Please check your profile for details.";
            $notif_sql = "INSERT INTO notifications (user_id, message) VALUES (?, ?)";
            $stmt_notif = $conn->prepare($notif_sql);
            $stmt_notif->bind_param("is", $user_id, $message);
            $stmt_notif->execute();
            $stmt_notif->close();
            $stmt_user->close();
        }
        $stmt->close();
        header("Location: admin_bookings.php");
        exit();
    }
}

// Fetch total users
$sql_users = "SELECT COUNT(*) AS total_users FROM users";
$result_users = $conn->query($sql_users);
$total_users = ($result_users->num_rows > 0) ? $result_users->fetch_assoc()['total_users'] : 0;

// Fetch count of accepted, rejected, and pending bookings
$sql_accepted = "SELECT COUNT(*) AS accepted_users FROM bookings WHERE payment_status = 'Accepted'";
$result_accepted = $conn->query($sql_accepted);
$accepted_users = ($result_accepted->num_rows > 0) ? $result_accepted->fetch_assoc()['accepted_users'] : 0;

$sql_rejected = "SELECT COUNT(*) AS rejected_users FROM bookings WHERE payment_status = 'Rejected'";
$result_rejected = $conn->query($sql_rejected);
$rejected_users = ($result_rejected->num_rows > 0) ? $result_rejected->fetch_assoc()['rejected_users'] : 0;

$sql_pending = "SELECT COUNT(*) AS pending_users FROM bookings WHERE payment_status = 'Pending'";
$result_pending = $conn->query($sql_pending);
$pending_users = ($result_pending->num_rows > 0) ? $result_pending->fetch_assoc()['pending_users'] : 0;

// Fetch bookings with payment proof, start date, and duration_text
$sql_bookings = "SELECT 
                    b.id, 
                    b.user_id, 
                    b.trainer_id, 
                    b.class_id, 
                    b.package_type, 
                    b.price, 
                    b.payment_status, 
                    b.payment_proof, 
                    b.start_date, 
                    b.duration_text, 
                    b.created_at, 
                    u.full_name AS user_name, 
                    t.name AS trainer_name, 
                    c.class_name 
                FROM bookings b
                JOIN users u ON b.user_id = u.id
                JOIN trainers t ON b.trainer_id = t.id
                JOIN classes c ON b.class_id = c.id
                ORDER BY b.payment_status = 'Pending' DESC, b.created_at DESC";

$stmt_bookings = $conn->prepare($sql_bookings);
$stmt_bookings->execute();
$result_bookings = $stmt_bookings->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Bookings</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            text-align: center;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 90%;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            background-color: #007bff;
            color: white;
            padding: 15px;
            font-size: 24px;
            font-weight: bold;
        }
        .btn {
            padding: 10px 15px;
            margin: 10px;
            cursor: pointer;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            transition: background 0.3s ease;
        }
        .btn-add { background-color: green; }
        .btn-add:hover { background-color: darkgreen; }
        .btn-view { background-color: orange; }
        .btn-view:hover { background-color: darkorange; }
        .btn-logout { background-color: red; }
        .btn-logout:hover { background-color: darkred; }
        .btn-users { background-color: blue; }
        .btn-users:hover { background-color: darkblue; }
        .btn-report { background-color: purple; }
        .btn-report:hover { background-color: darkviolet; }
        .btn-contacts { background-color: #17a2b8; } /* Teal for contact messages */
        .btn-contacts:hover { background-color: #138496; }

        .users-count {
            font-size: 20px;
            font-weight: bold;
            color: #333;
            margin-top: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .accepted { background-color: #d4edda; color: #155724; }
        .rejected { background-color: #f8d7da; color: #721c24; }
        .completed { background-color: #d1ecf1; color: #0c5460; }
    </style>
</head>
<body>
    <div class="header">Admin Bookings</div>

    <div class="container">
        <a href="admin_dashboard.php" class="btn btn-add">Add Class & Trainer</a>
        <a href="view_classes.php" class="btn btn-view">View Classes & Trainers</a>
        <a href="logout.php" class="btn btn-logout">Logout</a>
        <a href="admin_reports.php" class="btn btn-report">View Reports</a>
        <a href="admin_contacts.php" class="btn btn-contacts">View Contact Messages</a>

        <div class="users-count">Total Users: <?= $total_users; ?></div>

        <h2>User Bookings</h2>
        <table>
            <thead>
                <tr>
                    <th>User Name</th>
                    <th>Class</th>
                    <th>Trainer</th>
                    <th>Package</th>
                    <th>Price</th>
                    <th>Start Date</th>
                    <th>Duration</th>
                    <th>Status</th>
                    <th>Payment Proof</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result_bookings->fetch_assoc()): ?>
                    <tr class="<?= strtolower($row['payment_status']); ?>">
                        <td><?= htmlspecialchars($row['user_name']); ?></td>
                        <td><?= htmlspecialchars($row['class_name']); ?></td>
                        <td><?= htmlspecialchars($row['trainer_name']); ?></td>
                        <td><?= ucfirst(htmlspecialchars($row['package_type'])); ?></td>
                        <td>₹<?= htmlspecialchars($row['price']); ?></td>
                        <td><?= htmlspecialchars($row['start_date']); ?></td>
                        <td><?= htmlspecialchars($row['duration_text']) . ' Days'; ?></td>
                        <td><?= ucfirst(htmlspecialchars($row['payment_status'])); ?></td>
                        <td>
                            <?= !empty($row['payment_proof']) ? "<img src='uploads/{$row['payment_proof']}' width='80'>" : "No Proof"; ?>
                        </td>
                        <td>
                            <?php if ($row['payment_status'] == 'Pending'): ?>
                                <a href="?booking_id=<?= $row['id']; ?>&action=accept" class="btn btn-add">Accept</a>
                                <a href="?booking_id=<?= $row['id']; ?>&action=reject" class="btn btn-logout">Reject</a>
                            <?php elseif ($row['payment_status'] == 'Accepted'): ?>
                                <a href="?booking_id=<?= $row['id']; ?>&action=complete" class="btn btn-view">Complete</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
$stmt_bookings->close();
$conn->close();
?>