<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Database connection
include 'db.php';

// Get the class ID from the URL
$class_id = isset($_GET['class_id']) ? $_GET['class_id'] : 0;

// Fetch the class name for the selected class
$sql_class = "SELECT class_name FROM classes WHERE id = ?";
$stmt_class = $conn->prepare($sql_class);
$stmt_class->bind_param("i", $class_id);
$stmt_class->execute();
$result_class = $stmt_class->get_result();
$class_name = "";

if ($result_class->num_rows > 0) {
    $row_class = $result_class->fetch_assoc();
    $class_name = $row_class['class_name'];
}

// Delete trainer if requested
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_sql = "DELETE FROM trainers WHERE id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->bind_param("i", $delete_id);
    if ($delete_stmt->execute()) {
        echo "<script>alert('Trainer deleted successfully!'); window.location.href='view_trainers.php?class_id=$class_id';</script>";
    } else {
        echo "<script>alert('Failed to delete trainer.');</script>";
    }
    $delete_stmt->close();
}

// Fetch trainers for the selected class
$sql = "SELECT t.id, t.name, t.specialization, t.contact_number, t.email, t.image, t.dob 
        FROM trainers t 
        WHERE t.class_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $class_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Trainers</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            color: #333;
            padding-top: 20px;
        }
        nav {
            background-color: #007BFF;
            padding: 10px;
            text-align: center;
        }
        nav a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 0 10px;
            font-weight: bold;
        }
        nav a:hover {
            background-color: #0056b3;
            border-radius: 5px;
        }
        .container {
            max-width: 1000px;
            margin: 30px auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        .btn {
            text-decoration: none;
            color: white;
            background-color: #007BFF;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 12px;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .btn-danger {
            background-color: #DC3545;
        }
        .btn-danger:hover {
            background-color: #C82333;
        }
    </style>
</head>
<body>

    <h1>Trainers for Class: <?= $class_name; ?></h1>

    <!-- Navigation Links -->
    <nav>
        <a href="admin_dashboard.php">Admin Dashboard</a>
        <a href="view_classes.php">View Classes</a>
    </nav>

    <div class="container">
        <h2>Trainers for Class: <?= $class_name; ?></h2>

        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Specialization</th>
                        <th>Contact Number</th>
                        <th>Email</th>
                        <th>Image</th>
                        <th>Date of Birth</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['id']; ?></td>
                            <td><?= $row['name']; ?></td>
                            <td><?= $row['specialization']; ?></td>
                            <td><?= $row['contact_number']; ?></td>
                            <td><?= $row['email']; ?></td>
                            <td><img src="uploads/<?= $row['image']; ?>" alt="Trainer Image" width="50" height="50"></td>
                            <td><?= $row['dob']; ?></td>
                            <td>
                                <a href="update_trainer.php?trainer_id=<?= $row['id']; ?>" class="btn">Update</a>
                                <a href="view_trainers.php?class_id=<?= $class_id; ?>&delete_id=<?= $row['id']; ?>" 
                                   class="btn btn-danger" 
                                   onclick="return confirm('Are you sure you want to delete this trainer?');">
                                   Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No trainers available for this class.</p>
        <?php endif; ?>
    </div>

</body>
</html>

<?php
$stmt_class->close();
$stmt->close();
$conn->close();
?> 
