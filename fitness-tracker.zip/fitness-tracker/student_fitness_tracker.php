<?php
session_start();
include 'db.php';

// Check if the trainer is logged in
if (!isset($_SESSION['trainer_logged_in']) || $_SESSION['trainer_logged_in'] !== true) {
    header("Location: trainer_login.php");
    exit();
}

$trainer_id = $_SESSION['trainer_id'];

// Verify database connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Get trainer's name for the feedback (using 'name' instead of 'full_name')
$trainer_sql = "SELECT name FROM trainers WHERE id = ?";
$trainer_stmt = $conn->prepare($trainer_sql);

if ($trainer_stmt === false) {
    die("Prepare failed: " . $conn->error);
}

$trainer_stmt->bind_param("i", $trainer_id);
$success = $trainer_stmt->execute();

if (!$success) {
    die("Execute failed: " . $trainer_stmt->error);
}

$trainer_result = $trainer_stmt->get_result();
$trainer_data = $trainer_result->fetch_assoc();

if (!$trainer_data) {
    die("Trainer not found for ID: " . $trainer_id);
}

$trainer_name = $trainer_data['name'];
$trainer_stmt->close();

// Fetch unique users who have booked the trainer’s class
$sql = "SELECT DISTINCT users.id, users.full_name, fitness_tracking.weight, fitness_tracking.height, 
               fitness_tracking.bmi, fitness_tracking.bmi_category, fitness_tracking.extra_notes, 
               fitness_tracking.created_at
        FROM users
        JOIN bookings ON users.id = bookings.user_id
        JOIN fitness_tracking ON users.id = fitness_tracking.user_id 
        WHERE bookings.trainer_id = ?";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("SQL Error: " . $conn->error);
}

$stmt->bind_param("i", $trainer_id);
$stmt->execute();
$result = $stmt->get_result();
$users = [];

while ($row = $result->fetch_assoc()) {
    $users[$row['id']] = $row;
}
$stmt->close();

// Handle feedback submission
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $feedback = trim($_POST['feedback']);

    if (!empty($user_id) && !empty($feedback)) {
        // Insert into trainer_messages table (instead of trainer_feedback)
        $feedback_sql = "INSERT INTO trainer_messages (trainer_id, user_id, message, status, created_at) 
                        VALUES (?, ?, ?, 'unread', NOW())";
        $stmt = $conn->prepare($feedback_sql);
        
        if (!$stmt) {
            die("SQL Error: " . $conn->error);
        }

        $stmt->bind_param("iis", $trainer_id, $user_id, $feedback);
        
        // Insert into notifications table
        $notification_sql = "INSERT INTO notifications (user_id, message, status, created_at) 
                            VALUES (?, ?, 'unread', NOW())";
        $notification_stmt = $conn->prepare($notification_sql);
        
        $notification_message = "Feedback from Trainer $trainer_name at " . date('Y-m-d H:i:s') . ": " . $feedback;
        
        if (!$notification_stmt) {
            die("SQL Error: " . $conn->error);
        }

        $notification_stmt->bind_param("is", $user_id, $notification_message);

        if ($stmt->execute() && $notification_stmt->execute()) {
            $message = "Feedback sent successfully and notification created!";
        } else {
            $message = "Error sending feedback or creating notification.";
        }
        
        $stmt->close();
        $notification_stmt->close();
    } else {
        $message = "Please select a user and enter feedback.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trainer Dashboard - Student Fitness Tracker</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; margin: 0; padding: 0; }
        .header { background-color: #007bff; color: white; padding: 15px; text-align: center; font-size: 24px; }
        .container { width: 80%; margin: 20px auto; padding: 20px; background: white; border-radius: 10px; box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1); }
        h2 { text-align: center; color: #333; }
        .table-container { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table, th, td { border: 1px solid #ccc; text-align: center; padding: 10px; }
        th { background-color: #007bff; color: white; }
        .feedback-form { margin-top: 20px; padding: 15px; background: #f9f9f9; border-radius: 10px; }
        label { font-weight: bold; }
        textarea { width: 100%; height: 80px; padding: 10px; margin-top: 5px; border-radius: 5px; border: 1px solid #ccc; }
        select, button { width: 100%; padding: 10px; margin-top: 10px; border-radius: 5px; border: 1px solid #007bff; }
        button { background-color: #007bff; color: white; cursor: pointer; font-size: 16px; }
        button:hover { background-color: #0056b3; }
        .message { text-align: center; font-size: 16px; color: green; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Trainer Dashboard - Student Fitness Tracker</h1>
    </div>

    <div class="container">
        <h2>Fitness Reports</h2>
        <div class="table-container">
            <table>
                <tr>
                    <th>User ID</th>
                    <th>Full Name</th>
                    <th>Weight (kg)</th>
                    <th>Height (cm)</th>
                    <th>BMI</th>
                    <th>BMI Category</th>
                    <th>Extra Notes</th>
                    <th>Last Updated</th>
                </tr>
                <?php if (!empty($users)): ?>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?= htmlspecialchars($user['id']); ?></td>
                            <td><?= htmlspecialchars($user['full_name']); ?></td>
                            <td><?= htmlspecialchars($user['weight']); ?></td>
                            <td><?= htmlspecialchars($user['height']); ?></td>
                            <td><?= htmlspecialchars($user['bmi']); ?></td>
                            <td><?= htmlspecialchars($user['bmi_category']); ?></td>
                            <td><?= htmlspecialchars($user['extra_notes']); ?></td>
                            <td><?= htmlspecialchars($user['created_at']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="8">No fitness reports available.</td></tr>
                <?php endif; ?>
            </table>
        </div>

        <h2>Send Feedback & Suggestions</h2>
        <div class="feedback-form">
            <?php if ($message) { echo "<p class='message'>$message</p>"; } ?>
            <form action="" method="POST">
                <label for="user_id">Select User:</label>
                <select name="user_id" required>
                    <option value="">-- Select User --</option>
                    <?php foreach ($users as $user): ?>
                        <option value="<?= htmlspecialchars($user['id']); ?>"><?= htmlspecialchars($user['full_name']); ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="feedback">Feedback & Suggestions:</label>
                <textarea name="feedback" placeholder="Enter feedback here..." required></textarea>

                <button type="submit">Send Feedback</button>
            </form>
        </div>
    </div>
</body>
</html>