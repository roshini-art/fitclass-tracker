<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Database connection
include 'db.php';

// Fetch total classes and trainers count
$total_classes = $conn->query("SELECT COUNT(*) AS count FROM classes")->fetch_assoc()['count'];
$total_trainers = $conn->query("SELECT COUNT(*) AS count FROM trainers")->fetch_assoc()['count'];

// Initialize messages
$success_message = "";
$error_message = "";

// Handle Add Trainer form submission
if (isset($_POST['add_trainer'])) {
    $trainer_name = $_POST['trainer_name'];
    $specialization = $_POST['specialization'];
    $contact_number = $_POST['contact_number'];
    $email = $_POST['email'];
    $trainer_image = $_FILES['trainer_image']['name'];
    $class_id = $_POST['class_id'];
    $dob = $_POST['dob'];  // Added Date of Birth field

    // Generate a unique Trainer ID
    $result = $conn->query("SELECT MAX(trainer_id) AS max_id FROM trainers");
    $row = $result->fetch_assoc();
    $next_trainer_id = isset($row['max_id']) ? $row['max_id'] + 1 : 1;

    // Save trainer image (if uploaded)
    if (!empty($trainer_image)) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($trainer_image);
        move_uploaded_file($_FILES['trainer_image']['tmp_name'], $target_file);
    }

    // Insert new trainer into the database
    $sql = "INSERT INTO trainers (trainer_id, name, specialization, contact_number, email, class_id, image, dob) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";  // Added 'dob' to the query

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("isssssss", $next_trainer_id, $trainer_name, $specialization, $contact_number, $email, $class_id, $trainer_image, $dob);

        if ($stmt->execute()) {
            $success_message = "Trainer added successfully! Trainer ID: " . $next_trainer_id;
        } else {
            $error_message = "Error adding trainer: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $error_message = "Error preparing statement: " . $conn->error;
    }
}

// Handle Add Class form submission
if (isset($_POST['add_class'])) {
    $class_name = $_POST['class_name'];
    $description = $_POST['description'];
    $class_image = $_FILES['class_image']['name'];

    // Save class image (if uploaded)
    if (!empty($class_image)) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($class_image);
        move_uploaded_file($_FILES['class_image']['tmp_name'], $target_file);
    }

    // Insert new class into the database, including the class image
    $sql = "INSERT INTO classes (class_name, description, image) VALUES (?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("sss", $class_name, $description, $class_image);

        if ($stmt->execute()) {
            $class_id = $conn->insert_id;
            $success_message = "Class added successfully! Class ID: " . $class_id;
        } else {
            $error_message = "Error adding class: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $error_message = "Error preparing statement: " . $conn->error;
    }
}

// Fetch classes for the dropdown
$classes_result = $conn->query("SELECT id, class_name FROM classes");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        /* Header */
        h1 {
            text-align: center;
            color: #333;
            padding: 20px 0;
            font-size: 32px;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin: 0;
        }

        /* Navigation Bar */
        nav {
            background-color: #007BFF;
            padding: 10px 20px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
            width: 100%;
            display: flex;
            justify-content: center;
        }

        nav a {
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            margin: 0 10px;
            font-weight: bold;
            transition: background-color 0.3s, transform 0.3s;
            text-align: center;
        }

        nav a:hover {
            background-color: #0056b3;
            border-radius: 5px;
            transform: scale(1.1);
        }

        /* Main Container */
        .container {
            max-width: 1200px;
            width: 90%;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin: 30px auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            animation: fadeIn 1s ease-in-out;
        }

        /* Dashboard Stats */
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            width: 100%;
            margin-bottom: 30px;
            align-items: center;
        }

        .stat-box {
            background-color: #007BFF;
            color: white;
            padding: 20px 30px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, background-color 0.3s;
        }

        .stat-box:hover {
            transform: translateY(-5px);
            background-color: #0056b3;
        }

        .stat-box h3 {
            font-size: 36px;
            margin: 0;
            font-weight: bold;
        }

        .stat-box p {
            font-size: 18px;
            margin: 5px 0 0;
            font-weight: 500;
        }

        /* Forms */
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
            max-width: 600px;
            width: 100%;
            margin: 20px auto;
        }

        form label {
            font-weight: bold;
            color: #555;
        }

        form input, 
        form select, 
        form textarea {
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 100%;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
            transition: border-color 0.3s, box-shadow 0.3s;
        }

        form input:focus, 
        form select:focus, 
        form textarea:focus {
            border-color: #007BFF;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
            outline: none;
        }

        form input[type="submit"] {
            background-color: #28a745;
            color: white;
            font-weight: bold;
            border: none;
            cursor: pointer;
            padding: 12px;
            transition: background-color 0.3s, transform 0.3s;
            align-self: center;
            width: fit-content;
        }

        form input[type="submit"]:hover {
            background-color: #218838;
            transform: scale(1.05);
        }

        /* Success and Error Messages */
        .message {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            text-align: center;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
        }

        /* Sections */
        .section {
            width: 100%;
            text-align: center;
            margin-top: 40px;
            animation: slideInUp 1s ease;
        }

        .section h2 {
            color: #333;
            text-transform: uppercase;
            font-size: 24px;
            border-bottom: 2px solid #007BFF;
            display: inline-block;
            padding-bottom: 5px;
            margin-bottom: 20px;
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        @keyframes slideInUp {
            from {
                transform: translateY(30px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        /* Media Queries */
        @media (max-width: 768px) {
            .dashboard-stats {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            form input[type="submit"] {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<h1>Admin Dashboard</h1>

<!-- Navigation Links -->
<nav>
    <a href="#add-trainer-section">Add Trainer</a>
    <a href="#add-class-section">Add Class</a>
    <a href="view_classes.php">View Classes</a>
</nav>

<div class="container">
    <div class="dashboard-stats">
        <div class="stat-box">
            <h3><?php echo $total_trainers; ?></h3>
            <p>Total Trainers</p>
        </div>
        <div class="stat-box">
            <h3><?php echo $total_classes; ?></h3>
            <p>Total Classes</p>
        </div>
    </div>

    <!-- Success/Error Messages -->
    <?php if ($success_message) { ?>
        <div class="message success-message"><?php echo $success_message; ?></div>
    <?php } ?>
    <?php if ($error_message) { ?>
        <div class="message error-message"><?php echo $error_message; ?></div>
    <?php } ?>

    <!-- Add Trainer Section -->
    <div class="section" id="add-trainer-section">
        <h2>Add Trainer</h2>
        <form method="POST" enctype="multipart/form-data">
            <label for="trainer_name">Trainer Name:</label>
            <input type="text" name="trainer_name" id="trainer_name" required>

            <label for="specialization">Specialization:</label>
            <input type="text" name="specialization" id="specialization" required>

            <label for="contact_number">Contact Number:</label>
            <input type="tel" name="contact_number" id="contact_number" required>

            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>

            <label for="dob">Date of Birth:</label>
            <input type="date" name="dob" id="dob" required> <!-- Added Date of Birth input -->

            <label for="trainer_image">Trainer Image:</label>
            <input type="file" name="trainer_image" id="trainer_image">

            <label for="class_id">Class:</label>
            <select name="class_id" id="class_id" required>
                <?php while ($class = $classes_result->fetch_assoc()) { ?>
                    <option value="<?php echo $class['id']; ?>"><?php echo $class['class_name']; ?></option>
                <?php } ?>
            </select>

            <input type="submit" name="add_trainer" value="Add Trainer">
        </form>
    </div>

    <!-- Add Class Section -->
    <div class="section" id="add-class-section">
        <h2>Add Class</h2>
        <form method="POST" enctype="multipart/form-data">
            <label for="class_name">Class Name:</label>
            <input type="text" name="class_name" id="class_name" required>

            <label for="description">Description:</label>
            <textarea name="description" id="description" rows="5" required></textarea>

            <label for="class_image">Class Image:</label>
            <input type="file" name="class_image" id="class_image">

            <input type="submit" name="add_class" value="Add Class">
        </form>
    </div>
</div>

</body>
</html>
