<?php
include('db.php');

// Get class ID from URL
if (isset($_GET['id'])) {
    $class_id = $_GET['id'];

    // Fetch class details
    $class_sql = "SELECT * FROM classes WHERE id = $class_id";
    $class_result = $conn->query($class_sql);
    $class = $class_result->fetch_assoc();

    // Fetch trainers associated with this class
    $trainers_sql = "SELECT * FROM trainers WHERE class_id = $class_id";
    $trainers_result = $conn->query($trainers_sql);
} else {
    echo "Class ID is missing.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $class['class_name']; ?> Details</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            padding: 20px;
            color: #333;
        }
        .container {
            width: 80%;
            margin: 30px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .trainer-card {
            padding: 15px;
            margin-bottom: 10px;
            background-color: #f9f9f9;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
    </style>
</head>
<body>

    <h1><?= $class['class_name']; ?> Details</h1>

    <div class="container">
        <h3>Description: <?= $class['description']; ?></h3>
        <p><strong>Class Timing:</strong> <?= $class['timing']; ?></p>

        <h3>Trainers:</h3>
        <?php if ($trainers_result->num_rows > 0): ?>
            <?php while($trainer = $trainers_result->fetch_assoc()): ?>
                <div class="trainer-card">
                    <p><strong>Name:</strong> <?= $trainer['trainer_name']; ?></p>
                    <p><strong>Specialization:</strong> <?= $trainer['specialization']; ?></p>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No trainers found for this class.</p>
        <?php endif; ?>
    </div>

</body>
</html>
