<?php
include 'db.php';

if (isset($_GET['student_id'])) {
    $student_id = intval($_GET['student_id']);

    // Fetch messages for the specific student
    $sql = "SELECT message, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $messages = [];
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }

    $stmt->close();
    $conn->close();

    // Return messages as JSON
    echo json_encode($messages);
} else {
    echo json_encode(["error" => "Invalid request"]);
}
?>
